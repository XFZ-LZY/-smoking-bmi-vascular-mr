stopifnot(as.character(getRversion())=='4.6.1')
d <- read.csv('results/refitted_results.csv')
fdr <- p.adjust(d$smoking_p, method='BH')
stopifnot(max(abs(fdr-d$smoking_fdr))<1e-14,all(fdr>=0 & fdr<=1))
stopifnot(signif(fdr[1],3)==2.74e-4,signif(fdr[2],3)==4.36e-6,
          round(fdr[3],3)==0.029,round(fdr[5],3)==0.037)
print(data.frame(outcome=d$outcome,recalculated_FDR=fdr,stored_FDR=d$smoking_fdr))
cat('Reported four smoking FDR P values and signs: PASS\n')
