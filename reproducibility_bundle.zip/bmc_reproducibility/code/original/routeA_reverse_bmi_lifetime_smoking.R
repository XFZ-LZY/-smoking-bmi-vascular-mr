suppressPackageStartupMessages({
  library(data.table)
  library(TwoSampleMR)
})

set.seed(20260914)
root <- "audit_ascii/routeA_runs"
prefix <- "lifetime_union_mvmr_cad_bmi_"
candidates <- list.dirs(root, recursive = FALSE, full.names = TRUE)
candidates <- candidates[startsWith(basename(candidates), prefix)]
if (!length(candidates)) stop("No lifetime union-MVMR run found")
run_dir <- candidates[order(file.info(candidates)[, "mtime"], decreasing = TRUE)][1]

bmi_inst <- readRDS(file.path(run_dir, "bmi_instruments_initial.rds"))
full <- fread(
  "audit_ascii/Wootton2019_lifetime_smoking_full.txt",
  select = c("SNP", "EFFECT_ALLELE", "OTHER_ALLELE", "EAF", "INFO", "BETA", "SE", "P"),
  data.table = FALSE,
  showProgress = TRUE
)

target <- data.frame(
  SNP = bmi_inst$SNP,
  reference_effect_allele = bmi_inst$effect_allele.exposure,
  reference_other_allele = bmi_inst$other_allele.exposure,
  stringsAsFactors = FALSE
)
matched <- merge(target, full, by = "SNP", all.x = TRUE, sort = FALSE)
matched$allele_match <- with(
  matched,
  (EFFECT_ALLELE == reference_effect_allele & OTHER_ALLELE == reference_other_allele) |
    (EFFECT_ALLELE == reference_other_allele & OTHER_ALLELE == reference_effect_allele)
)
matched <- matched[matched$allele_match %in% TRUE, , drop = FALSE]
matched <- matched[order(matched$SNP, -matched$INFO), , drop = FALSE]
matched <- matched[!duplicated(matched$SNP), , drop = FALSE]
missing <- setdiff(bmi_inst$SNP, matched$SNP)
writeLines(missing, file.path(run_dir, "reverse_bmi_lifetime_missing_snps.txt"))

sd_lifetime <- 0.6940093
life_raw <- data.frame(
  SNP = matched$SNP,
  beta = matched$BETA / sd_lifetime,
  se = matched$SE / sd_lifetime,
  effect_allele = matched$EFFECT_ALLELE,
  other_allele = matched$OTHER_ALLELE,
  eaf = matched$EAF,
  pval = matched$P,
  samplesize = 462690,
  phenotype = "Lifetime smoking index per 1 SD",
  stringsAsFactors = FALSE
)
life_out <- format_data(
  life_raw, type = "outcome", snp_col = "SNP", beta_col = "beta",
  se_col = "se", effect_allele_col = "effect_allele",
  other_allele_col = "other_allele", eaf_col = "eaf", pval_col = "pval",
  samplesize_col = "samplesize", phenotype_col = "phenotype"
)
life_out$id.outcome <- "Wootton2019_lifetime_smoking"
life_out$outcome <- "Lifetime smoking index per 1 SD (Wootton et al. 2019)"

dat <- harmonise_data(bmi_inst, life_out, action = 2)
dat <- dat[dat$mr_keep, , drop = FALSE]
dat$F_snp <- (dat$beta.exposure / dat$se.exposure)^2
stopifnot(nrow(dat) >= 3L)

methods <- c("mr_ivw_mre", "mr_weighted_median", "mr_weighted_mode", "mr_egger_regression")
res <- mr(dat, method_list = methods)
het <- mr_heterogeneity(dat)
pleio <- mr_pleiotropy_test(dat)
loo <- mr_leaveoneout(dat)

saveRDS(dat, file.path(run_dir, "reverse_bmi_to_lifetime_harmonised.rds"))
saveRDS(res, file.path(run_dir, "reverse_bmi_to_lifetime_mr.rds"))
write.csv(dat, file.path(run_dir, "reverse_bmi_to_lifetime_harmonised.csv"), row.names = FALSE, na = "")
write.csv(res, file.path(run_dir, "reverse_bmi_to_lifetime_mr.csv"), row.names = FALSE, na = "")
write.csv(het, file.path(run_dir, "reverse_bmi_to_lifetime_heterogeneity.csv"), row.names = FALSE, na = "")
write.csv(pleio, file.path(run_dir, "reverse_bmi_to_lifetime_egger_intercept.csv"), row.names = FALSE, na = "")
write.csv(loo, file.path(run_dir, "reverse_bmi_to_lifetime_leave_one_out.csv"), row.names = FALSE, na = "")

ivw <- res[res$method == "Inverse variance weighted (multiplicative random effects)", ]
summary <- c(
  paste0("BMI instruments initial=", nrow(bmi_inst)),
  paste0("missing from lifetime GWAS after allele-pair matching=", length(missing)),
  paste0("harmonised SNPs=", nrow(dat), "; mean F=", signif(mean(dat$F_snp), 8)),
  paste0("BMI->lifetime smoking IVW beta=", signif(ivw$b, 8),
         "; SE=", signif(ivw$se, 8), "; P=", signif(ivw$pval, 8))
)
writeLines(summary, file.path(run_dir, "reverse_bmi_to_lifetime_summary.txt"))
cat(paste(summary, collapse = "\n"), "\n")
