suppressPackageStartupMessages(library(TwoSampleMR))

options(timeout = 900)
set.seed(20260914)

jwt <- Sys.getenv("OPENGWAS_JWT")
stopifnot(nchar(jwt) > 100)

root <- "audit_ascii/routeA_runs"
dir.create(root, recursive = TRUE, showWarnings = FALSE)
run_id <- format(Sys.time(), "%Y%m%d_%H%M%S")
outdir <- file.path(root, paste0("lifetime_smoking_primary_outcomes_", run_id))
dir.create(outdir, recursive = TRUE, showWarnings = FALSE)

outcomes <- data.frame(
  outcome_key = c("cad", "pad_finngen_r5", "ais", "laa", "svs", "ces"),
  outcome_id = c(
    "ieu-a-7", "finn-b-I9_PAD", "ebi-a-GCST005843",
    "ebi-a-GCST005840", "ebi-a-GCST005841", "ebi-a-GCST005842"
  ),
  outcome_label = c(
    "Coronary artery disease",
    "Peripheral artery disease (FinnGen R5 endpoint I9_PAD)",
    "Any ischemic stroke (MEGASTROKE European)",
    "Large-artery atherosclerotic stroke (MEGASTROKE European)",
    "Small-vessel stroke (MEGASTROKE European)",
    "Cardioembolic stroke (MEGASTROKE European)"
  ),
  primary_family = c(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE),
  stringsAsFactors = FALSE
)
write.csv(outcomes, file.path(outdir, "analysis_outcomes.csv"), row.names = FALSE)

save_csv_rds <- function(x, stem) {
  saveRDS(x, file.path(outdir, paste0(stem, ".rds")))
  if (is.data.frame(x) || is.matrix(x)) {
    write.csv(x, file.path(outdir, paste0(stem, ".csv")), row.names = FALSE, na = "")
  }
}

s1 <- read.table(
  "audit_ascii/Wootton2019_lifetime_smoking_GWS_126.txt",
  header = TRUE, stringsAsFactors = FALSE
)
stopifnot(nrow(s1) == 126L, !anyDuplicated(s1$SNP))
lifetime_smoking_sd <- 0.6940093

exposure_raw <- data.frame(
  SNP = s1$SNP,
  beta = as.numeric(s1$BETA) / lifetime_smoking_sd,
  se = as.numeric(s1$SE) / lifetime_smoking_sd,
  effect_allele = toupper(s1$EFFECT_ALLELE),
  other_allele = toupper(s1$OTHER_ALLELE),
  eaf = as.numeric(s1$EAF),
  pval = as.numeric(s1$P),
  samplesize = 462690,
  phenotype = "Lifetime smoking index per 1 SD",
  stringsAsFactors = FALSE
)
stopifnot(all(is.finite(exposure_raw$beta)))
stopifnot(all(is.finite(exposure_raw$se)), all(exposure_raw$se > 0))

exp_dat <- format_data(
  exposure_raw,
  type = "exposure",
  snp_col = "SNP",
  beta_col = "beta",
  se_col = "se",
  effect_allele_col = "effect_allele",
  other_allele_col = "other_allele",
  eaf_col = "eaf",
  pval_col = "pval",
  samplesize_col = "samplesize",
  phenotype_col = "phenotype"
)
exp_dat$id.exposure <- "Wootton2019_lifetime_smoking"
exp_dat$exposure <- "Lifetime smoking index per 1 SD (Wootton et al. 2019)"
exp_dat$F_snp <- (exp_dat$beta.exposure / exp_dat$se.exposure)^2
save_csv_rds(exp_dat, "formatted_lifetime_smoking_instruments")

methods <- c(
  "mr_ivw_mre",
  "mr_weighted_median",
  "mr_weighted_mode",
  "mr_egger_regression"
)

all_mr <- list()
all_het <- list()
all_pleio <- list()
counts <- list()

for (i in seq_len(nrow(outcomes))) {
  key <- outcomes$outcome_key[i]
  oid <- outcomes$outcome_id[i]
  label <- outcomes$outcome_label[i]
  message("Extracting ", key, " (", oid, ")")

  out_raw <- extract_outcome_data(
    snps = exp_dat$SNP,
    outcomes = oid,
    proxies = TRUE,
    rsq = 0.8,
    align_alleles = 1,
    palindromes = 1,
    maf_threshold = 0.3,
    opengwas_jwt = jwt
  )
  dat <- harmonise_data(exp_dat, out_raw, action = 2)
  dat <- dat[dat$mr_keep, , drop = FALSE]
  stopifnot(nrow(dat) >= 3L)
  dat$outcome_key <- key
  dat$outcome_label_frozen <- label

  res <- mr(dat, method_list = methods)
  het <- mr_heterogeneity(dat)
  pleio <- mr_pleiotropy_test(dat)
  loo <- mr_leaveoneout(dat)
  single <- mr_singlesnp(dat)

  res$outcome_key <- key
  res$outcome_label_frozen <- label
  res$or <- exp(res$b)
  res$or_lci95 <- exp(res$b - 1.96 * res$se)
  res$or_uci95 <- exp(res$b + 1.96 * res$se)
  het$outcome_key <- key
  pleio$outcome_key <- key

  save_csv_rds(out_raw, paste0(key, "_raw_associations"))
  save_csv_rds(dat, paste0(key, "_harmonised"))
  save_csv_rds(res, paste0(key, "_mr"))
  save_csv_rds(het, paste0(key, "_heterogeneity"))
  save_csv_rds(pleio, paste0(key, "_egger_intercept"))
  save_csv_rds(loo, paste0(key, "_leave_one_out"))
  save_csv_rds(single, paste0(key, "_single_snp"))

  all_mr[[key]] <- res
  all_het[[key]] <- het
  all_pleio[[key]] <- pleio
  counts[[key]] <- data.frame(
    outcome_key = key,
    outcome_id = oid,
    raw_associations = nrow(out_raw),
    harmonised_mr_snps = nrow(dat),
    stringsAsFactors = FALSE
  )
}

mr_panel <- do.call(rbind, all_mr)
het_panel <- do.call(rbind, all_het)
pleio_panel <- do.call(rbind, all_pleio)
count_panel <- do.call(rbind, counts)
rownames(mr_panel) <- NULL
rownames(het_panel) <- NULL
rownames(pleio_panel) <- NULL
rownames(count_panel) <- NULL

ivw_name <- "Inverse variance weighted (multiplicative random effects)"
ivw_panel <- mr_panel[mr_panel$method == ivw_name, , drop = FALSE]
stopifnot(nrow(ivw_panel) == nrow(outcomes))
ivw_panel$p_fdr_bh_six_outcomes <- p.adjust(ivw_panel$pval, method = "BH")
ivw_panel$significant_fdr_0_05 <- ivw_panel$p_fdr_bh_six_outcomes < 0.05

save_csv_rds(mr_panel, "all_outcomes_all_methods")
save_csv_rds(ivw_panel, "all_outcomes_ivw_fdr")
save_csv_rds(het_panel, "all_outcomes_heterogeneity")
save_csv_rds(pleio_panel, "all_outcomes_egger_intercept")
save_csv_rds(count_panel, "all_outcomes_snp_counts")

summary_lines <- c(
  paste0("run_id=", run_id),
  paste0("output_dir=", normalizePath(outdir, winslash = "/", mustWork = TRUE)),
  paste0("R=", R.version.string),
  paste0("TwoSampleMR=", as.character(packageVersion("TwoSampleMR"))),
  paste0("lifetime smoking instruments=", nrow(exp_dat),
         "; mean F=", signif(mean(exp_dat$F_snp), 8),
         "; minimum F=", signif(min(exp_dat$F_snp), 8)),
  "FDR family: six prespecified atherosclerotic/stroke outcomes in this run.",
  "FinnGen PAD is an independent replication outcome and is not the MVP dataset used by Levin et al. 2021.",
  "MEGASTROKE 2018 predates the later UK Biobank+MEGASTROKE meta-analysis."
)
for (i in seq_len(nrow(ivw_panel))) {
  z <- ivw_panel[i, ]
  summary_lines <- c(
    summary_lines,
    paste0(
      z$outcome_key, ": nsnp=", z$nsnp,
      "; beta=", signif(z$b, 8),
      "; SE=", signif(z$se, 8),
      "; OR=", signif(z$or, 8),
      "; 95% CI=", signif(z$or_lci95, 8), " to ", signif(z$or_uci95, 8),
      "; P=", signif(z$pval, 8),
      "; BH-FDR P=", signif(z$p_fdr_bh_six_outcomes, 8)
    )
  )
}
writeLines(summary_lines, file.path(outdir, "run_summary.txt"))
writeLines(capture.output(sessionInfo()), file.path(outdir, "sessionInfo.txt"))
cat(paste(summary_lines, collapse = "\n"), "\n")
