suppressPackageStartupMessages(library(ggplot2))

options(stringsAsFactors = FALSE)
set.seed(20260914)

command_line <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", command_line, value = TRUE)
script_path <- if (length(file_arg)) sub("^--file=", "", file_arg[1]) else "audit_ascii/final_article_analysis.R"
script_dir <- dirname(script_path)
candidate_bundle <- dirname(script_dir)
standalone <- basename(script_dir) == "code" && dir.exists(file.path(candidate_bundle, "data_archive"))

# R on some Windows locale configurations exposes non-ASCII --file paths as
# escaped bytes. Fall back to discovering the unique offline bundle below the
# working directory, identified by a code/ script and sibling data_archive/.
if (!standalone) {
  discovered <- list.files(
    getwd(), pattern = "^final_article_analysis[.]R$",
    recursive = TRUE, full.names = TRUE
  )
  discovered_bundles <- unique(dirname(dirname(discovered)))
  discovered_bundles <- discovered_bundles[
    dir.exists(file.path(discovered_bundles, "data_archive"))
  ]
  if (length(discovered_bundles) == 1L) {
    candidate_bundle <- discovered_bundles[1]
    standalone <- TRUE
  }
}

if (standalone) {
  bundle <- candidate_bundle
} else {
  root <- "audit_ascii"
  primary_dir <- file.path(root, "routeA_runs", "lifetime_smoking_primary_outcomes_20260914_105437")
  mvmr_dir <- file.path(root, "routeA_runs", "lifetime_bmi_mvmr_outcome_panel_20260914_180805")
  source_dir <- file.path(root, "routeA_runs", "lifetime_union_mvmr_cad_bmi_20260914_065950")
  bundle <- file.path(root, "article_lifetime_smoking_bmi_vascular_beds")
}
dirs <- file.path(bundle, c("code", "data_archive", "results", "figures", "manuscript"))
invisible(lapply(dirs, dir.create, recursive = TRUE, showWarnings = FALSE))

required_names <- c(
  "all_outcomes_all_methods.csv", "all_outcomes_ivw_fdr.csv", "analysis_outcomes.csv",
  "mvmr_bmi_outcome_panel_summary.csv", "x_to_m_mr.csv",
  "all_outcomes_heterogeneity.csv", "all_outcomes_egger_intercept.csv",
  "reverse_bmi_to_lifetime_mr.csv"
)
required <- if (standalone) {
  file.path(dirs[2], required_names)
} else {
  c(
    file.path(primary_dir, required_names[1]),
    file.path(primary_dir, required_names[2]),
    file.path(primary_dir, required_names[3]),
    file.path(mvmr_dir, required_names[4]),
    file.path(source_dir, required_names[5]),
    file.path(primary_dir, required_names[6]),
    file.path(primary_dir, required_names[7]),
    file.path(source_dir, required_names[8])
  )
}
stopifnot(all(file.exists(required)))

copy_checked <- function(from, to_dir) {
  ok <- file.copy(from, file.path(to_dir, basename(from)), overwrite = TRUE, copy.date = TRUE)
  stopifnot(ok)
}

# Freeze all inputs needed to reproduce the article without an API token.
if (!standalone) {
  invisible(lapply(required, copy_checked, to_dir = dirs[2]))
  raw_files <- c(
    list.files(primary_dir, pattern = "(_harmonised|_raw_associations)\\.(csv|rds)$", full.names = TRUE),
    list.files(mvmr_dir, pattern = "(_outcome_associations_raw|_mvmr_harmonised|_mvmr_input)\\.(csv|rds)$", full.names = TRUE),
    list.files(source_dir, pattern = "(mvmr_exposure_union_harmonised|x_to_m_harmonised)\\.(csv|rds)$", full.names = TRUE)
  )
  invisible(lapply(unique(raw_files), copy_checked, to_dir = dirs[2]))
}

all_methods <- read.csv(required[1], check.names = FALSE)
total <- read.csv(required[2], check.names = FALSE)
outcomes <- read.csv(required[3], check.names = FALSE)
mv <- read.csv(required[4], check.names = FALSE)
x_to_m <- read.csv(required[5], check.names = FALSE)
heterogeneity <- read.csv(required[6], check.names = FALSE)
egger_intercept <- read.csv(required[7], check.names = FALSE)
reverse_mr <- read.csv(required[8], check.names = FALSE)

order_keys <- c("cad", "pad_finngen_r5", "ais", "laa", "svs", "ces")
short_labels <- c(
  cad = "Coronary artery disease",
  pad_finngen_r5 = "Peripheral artery disease",
  ais = "Any ischemic stroke",
  laa = "Large-artery stroke",
  svs = "Small-vessel stroke",
  ces = "Cardioembolic stroke"
)

stopifnot(setequal(total$outcome_key, order_keys), setequal(mv$key, order_keys))
total <- total[match(order_keys, total$outcome_key), ]
mv <- mv[match(order_keys, mv$key), ]
stopifnot(all(total$outcome_key == mv$key))

total$p_fdr_bh <- p.adjust(total$pval, method = "BH")
total$label <- unname(short_labels[total$outcome_key])
total$estimate_type <- "Total effect of lifetime smoking"

direct_long <- rbind(
  data.frame(
    key = mv$key, label = unname(short_labels[mv$key]), exposure = "Lifetime smoking",
    b = mv$smoking_direct_ivw, se = mv$se_smoking_direct_ivw,
    p = mv$p_smoking_direct_ivw
  ),
  data.frame(
    key = mv$key, label = unname(short_labels[mv$key]), exposure = "Body mass index",
    b = mv$bmi_direct_ivw, se = mv$se_bmi_direct_ivw,
    p = mv$p_bmi_direct_ivw
  )
)
direct_long$lci <- direct_long$b - 1.96 * direct_long$se
direct_long$uci <- direct_long$b + 1.96 * direct_long$se
direct_long$or <- exp(direct_long$b)
direct_long$or_lci <- exp(direct_long$lci)
direct_long$or_uci <- exp(direct_long$uci)
direct_long$p_fdr_bh_within_exposure <- ave(
  direct_long$p, direct_long$exposure,
  FUN = function(z) p.adjust(z, method = "BH")
)

a_ivw <- x_to_m[x_to_m$method == "Inverse variance weighted (multiplicative random effects)", ]
stopifnot(nrow(a_ivw) == 1L)

indirect <- data.frame(
  key = mv$key,
  label = unname(short_labels[mv$key]),
  a_smoking_to_bmi = mv$a_smoking_to_bmi,
  se_a = mv$se_a,
  b_bmi_to_outcome_conditional = mv$bmi_direct_ivw,
  se_b = mv$se_bmi_direct_ivw,
  indirect_log_or = mv$indirect_effect,
  indirect_lci = mv$indirect_lci,
  indirect_uci = mv$indirect_uci,
  p_indirect = mv$p_indirect,
  p_indirect_fdr = p.adjust(mv$p_indirect, method = "BH"),
  total_log_or = mv$total_effect,
  total_p = mv$p_total,
  proportion_descriptive = mv$descriptive_proportion,
  interpretable_proportion = mv$p_total < 0.05 & sign(mv$indirect_effect) == sign(mv$total_effect)
)
indirect$indirect_or <- exp(indirect$indirect_log_or)
indirect$proportion_descriptive[!indirect$interpretable_proportion] <- NA_real_

mvmr_table <- data.frame(
  key = mv$key,
  outcome = unname(short_labels[mv$key]),
  nsnp = mv$nsnp,
  smoking_direct_or = exp(mv$smoking_direct_ivw),
  smoking_direct_lci = exp(mv$smoking_direct_ivw - 1.96 * mv$se_smoking_direct_ivw),
  smoking_direct_uci = exp(mv$smoking_direct_ivw + 1.96 * mv$se_smoking_direct_ivw),
  smoking_direct_p = mv$p_smoking_direct_ivw,
  bmi_direct_or = exp(mv$bmi_direct_ivw),
  bmi_direct_lci = exp(mv$bmi_direct_ivw - 1.96 * mv$se_bmi_direct_ivw),
  bmi_direct_uci = exp(mv$bmi_direct_ivw + 1.96 * mv$se_bmi_direct_ivw),
  bmi_direct_p = mv$p_bmi_direct_ivw,
  bmi_direct_p_fdr = p.adjust(mv$p_bmi_direct_ivw, method = "BH"),
  conditional_F_smoking = mv$conditional_F_smoking,
  conditional_F_bmi = mv$conditional_F_bmi,
  residual_Q = mv$Q,
  residual_Q_p = mv$Q_p,
  bmi_robust_b = mv$bmi_direct_robust,
  bmi_robust_p = mv$p_bmi_direct_robust,
  bmi_egger_b = mv$bmi_direct_egger,
  bmi_egger_p = mv$p_bmi_direct_egger,
  bmi_median_b = mv$bmi_direct_median,
  bmi_median_p = mv$p_bmi_direct_median,
  egger_intercept = mv$egger_intercept,
  egger_intercept_p = mv$p_egger_intercept
)

write.csv(total, file.path(dirs[3], "table_total_effects.csv"), row.names = FALSE, na = "")
write.csv(all_methods, file.path(dirs[3], "table_total_effects_all_methods.csv"), row.names = FALSE, na = "")
write.csv(mvmr_table, file.path(dirs[3], "table_multivariable_mr.csv"), row.names = FALSE, na = "")
write.csv(indirect, file.path(dirs[3], "table_exploratory_indirect_effects.csv"), row.names = FALSE, na = "")
write.csv(direct_long, file.path(dirs[3], "direct_effects_long.csv"), row.names = FALSE, na = "")

theme_set(theme_minimal(base_size = 11))
label_levels <- rev(unname(short_labels[order_keys]))
save_png_safe <- function(filename, plot, width, height, dpi = 300) {
  tmp <- file.path(tempdir(), basename(filename))
  ggsave(tmp, plot, width = width, height = height, dpi = dpi, device = "png")
  stopifnot(file.exists(tmp), file.info(tmp)$size > 0)
  stopifnot(file.copy(tmp, filename, overwrite = TRUE))
}

p1 <- ggplot(total, aes(x = or, y = factor(label, levels = label_levels))) +
  geom_vline(xintercept = 1, linetype = 2, colour = "grey45") +
  geom_errorbar(aes(xmin = or_lci95, xmax = or_uci95), orientation = "y", width = 0.18, linewidth = 0.6) +
  geom_point(aes(colour = p_fdr_bh < 0.05), size = 2.6) +
  scale_x_log10() +
  scale_colour_manual(values = c(`TRUE` = "#B2182B", `FALSE` = "#777777"), guide = "none") +
  labs(x = "Odds ratio per 1-SD higher lifetime smoking index (log scale)", y = NULL,
       title = "Total effects of lifetime smoking", subtitle = "Random-effects inverse-variance weighted MR; BH-FDR across six outcomes") +
  theme(panel.grid.minor = element_blank())
save_png_safe(file.path(dirs[4], "figure2_total_effects.png"), p1, width = 8.2, height = 4.8)
ggsave(file.path(dirs[4], "figure2_total_effects.pdf"), p1, width = 8.2, height = 4.8)

p2 <- ggplot(direct_long, aes(x = or, y = factor(label, levels = label_levels), colour = exposure)) +
  geom_vline(xintercept = 1, linetype = 2, colour = "grey45") +
  geom_errorbar(aes(xmin = or_lci, xmax = or_uci), orientation = "y", width = 0.16, position = position_dodge(width = 0.42)) +
  geom_point(position = position_dodge(width = 0.42), size = 2.4) +
  scale_x_log10() +
  scale_colour_manual(values = c("Lifetime smoking" = "#B2182B", "Body mass index" = "#2166AC")) +
  labs(x = "Mutually adjusted odds ratio (log scale)", y = NULL, colour = NULL,
       title = "Direct effects in multivariable Mendelian randomization",
       subtitle = "Union of smoking- and BMI-associated variants") +
  theme(panel.grid.minor = element_blank(), legend.position = "top")
save_png_safe(file.path(dirs[4], "figure3_mvmr_direct_effects.png"), p2, width = 8.2, height = 5.0)
ggsave(file.path(dirs[4], "figure3_mvmr_direct_effects.pdf"), p2, width = 8.2, height = 5.0)

pathway <- data.frame(
  x = c(1, 3, 3), y = c(2, 3, 1),
  label = c("Lifetime smoking index\n126 instruments; N=462,690", "Body mass index\nGIANT; N=322,154", "Six vascular outcomes\nCAD, PAD and stroke subtypes")
)
p0 <- ggplot() +
  annotate("segment", x = 1.35, xend = 2.62, y = 2.12, yend = 2.88,
           arrow = grid::arrow(length = grid::unit(0.18, "cm")), linewidth = 0.8) +
  annotate("segment", x = 1.35, xend = 2.62, y = 1.88, yend = 1.12,
           arrow = grid::arrow(length = grid::unit(0.18, "cm")), linewidth = 0.8) +
  annotate("segment", x = 3, xend = 3, y = 2.65, yend = 1.35,
           arrow = grid::arrow(length = grid::unit(0.18, "cm")), linewidth = 0.8) +
  annotate("label", x = pathway$x, y = pathway$y, label = pathway$label,
           size = 4.2, linewidth = 0.5, fill = c("#FDDDBC", "#D8EAF6", "#E6E6E6")) +
  annotate("text", x = 1.95, y = 2.68, label = "A path", size = 3.6) +
  annotate("text", x = 1.95, y = 1.32, label = "Total and direct effects", size = 3.6) +
  annotate("text", x = 3.18, y = 2.0, label = "Conditional BMI effect", angle = 90, size = 3.6) +
  coord_cartesian(xlim = c(0.5, 3.7), ylim = c(0.5, 3.5), clip = "off") +
  theme_void() +
  labs(title = "Study design",
       subtitle = "MR assumptions: instrument relevance; independence from confounders; no outcome pathway outside the modeled exposures") +
  theme(plot.subtitle = element_text(size = 9, colour = "grey30"))
save_png_safe(file.path(dirs[4], "figure1_study_design.png"), p0, width = 8.2, height = 4.8)
ggsave(file.path(dirs[4], "figure1_study_design.pdf"), p0, width = 8.2, height = 4.8)

# Supplementary evidence package. Its structure follows the role of supplementary
# material in comparable MR papers: complete estimators, diagnostics, directionality,
# and influence analyses rather than additional headline outcomes.
data_sources <- data.frame(
  role = c("Exposure", "Exposure/mediator", rep("Outcome", 6)),
  phenotype = c("Lifetime smoking index", "Body mass index", unname(short_labels[order_keys])),
  source = c("UK Biobank / Wootton et al. 2019", "GIANT / Locke et al. 2015",
             "CARDIoGRAMplusC4D / Nikpay et al. 2015", "FinnGen release 5",
             rep("MEGASTROKE / Malik et al. 2018", 4)),
  identifier = c("Wootton2019_lifetime_smoking", "ieu-a-835", outcomes$outcome_id[match(order_keys, outcomes$outcome_key)]),
  ancestry = c("European", "European", "Mixed (77% European)", rep("European", 5)),
  sample = c("462,690 participants", "322,154 participants", "60,801 cases; 123,504 controls",
             "7,098 cases; 206,541 controls", "34,217 cases; 406,111 controls",
             "4,373 cases; 406,111 controls", "5,386 cases; 406,111 controls",
             "7,193 cases; 406,111 controls"),
  stringsAsFactors = FALSE
)
write.csv(data_sources, file.path(dirs[3], "table_s1_data_sources.csv"), row.names = FALSE, na = "")
write.csv(all_methods, file.path(dirs[3], "table_s2_total_effects_all_estimators.csv"), row.names = FALSE, na = "")

het_ivw <- heterogeneity[heterogeneity$method == "Inverse variance weighted", c("outcome_key", "Q", "Q_df", "Q_pval")]
diag_table <- merge(het_ivw, egger_intercept[, c("outcome_key", "egger_intercept", "se", "pval")], by = "outcome_key", all = TRUE)
names(diag_table)[names(diag_table) == "se"] <- "egger_intercept_se"
names(diag_table)[names(diag_table) == "pval"] <- "egger_intercept_p"
diag_table$label <- unname(short_labels[diag_table$outcome_key])
diag_table <- diag_table[match(order_keys, diag_table$outcome_key), ]
write.csv(diag_table, file.path(dirs[3], "table_s3_univariable_diagnostics.csv"), row.names = FALSE, na = "")

se_from_bp <- function(b, p) {
  z <- qnorm(pmax(pmin(p, 1 - 1e-15), 1e-300) / 2, lower.tail = FALSE)
  ifelse(is.finite(z) & z > 0, abs(b) / z, NA_real_)
}
mvmr_sensitivity <- rbind(
  data.frame(key = mv$key, label = unname(short_labels[mv$key]), method = "IVW", b = mv$bmi_direct_ivw, se = mv$se_bmi_direct_ivw, p = mv$p_bmi_direct_ivw),
  data.frame(key = mv$key, label = unname(short_labels[mv$key]), method = "Robust IVW", b = mv$bmi_direct_robust, se = se_from_bp(mv$bmi_direct_robust, mv$p_bmi_direct_robust), p = mv$p_bmi_direct_robust),
  data.frame(key = mv$key, label = unname(short_labels[mv$key]), method = "MVMR-Egger", b = mv$bmi_direct_egger, se = se_from_bp(mv$bmi_direct_egger, mv$p_bmi_direct_egger), p = mv$p_bmi_direct_egger),
  data.frame(key = mv$key, label = unname(short_labels[mv$key]), method = "Multivariable median", b = mv$bmi_direct_median, se = se_from_bp(mv$bmi_direct_median, mv$p_bmi_direct_median), p = mv$p_bmi_direct_median)
)
mvmr_sensitivity$or <- exp(mvmr_sensitivity$b)
mvmr_sensitivity$lci <- exp(mvmr_sensitivity$b - 1.96 * mvmr_sensitivity$se)
mvmr_sensitivity$uci <- exp(mvmr_sensitivity$b + 1.96 * mvmr_sensitivity$se)
write.csv(mvmr_sensitivity, file.path(dirs[3], "table_s4_mvmr_bmi_sensitivity.csv"), row.names = FALSE, na = "")

directionality <- rbind(
  data.frame(direction = "Lifetime smoking to BMI", method = x_to_m$method, nsnp = x_to_m$nsnp, b = x_to_m$b, se = x_to_m$se, p = x_to_m$pval),
  data.frame(direction = "BMI to lifetime smoking", method = reverse_mr$method, nsnp = reverse_mr$nsnp, b = reverse_mr$b, se = reverse_mr$se, p = reverse_mr$pval)
)
directionality$lci <- directionality$b - 1.96 * directionality$se
directionality$uci <- directionality$b + 1.96 * directionality$se
write.csv(directionality, file.path(dirs[3], "table_s5_bidirectional_smoking_bmi.csv"), row.names = FALSE, na = "")

ivw_re <- function(d) {
  d <- d[is.finite(d$beta.exposure) & is.finite(d$beta.outcome) & is.finite(d$se.outcome) & d$se.outcome > 0, ]
  w <- 1 / d$se.outcome^2
  b <- sum(w * d$beta.exposure * d$beta.outcome) / sum(w * d$beta.exposure^2)
  q <- sum(w * (d$beta.outcome - b * d$beta.exposure)^2)
  phi <- max(1, q / (nrow(d) - 1))
  se <- sqrt(phi / sum(w * d$beta.exposure^2))
  c(b = b, se = se, q = q, n = nrow(d))
}
loo_rows <- list()
for (key in order_keys) {
  dat <- read.csv(file.path(dirs[2], paste0(key, "_harmonised.csv")), check.names = FALSE)
  dat <- dat[dat$mr_keep %in% TRUE, ]
  full <- ivw_re(dat)
  estimates <- vapply(seq_len(nrow(dat)), function(i) ivw_re(dat[-i, ])["b"], numeric(1))
  loo_rows[[key]] <- data.frame(
    key = key, label = unname(short_labels[key]), nsnp = full["n"], full_b = full["b"], full_se = full["se"],
    loo_min_b = min(estimates), loo_max_b = max(estimates),
    max_abs_change = max(abs(estimates - full["b"])),
    most_influential_snp = dat$SNP[which.max(abs(estimates - full["b"]))]
  )
}
loo_summary <- do.call(rbind, loo_rows)
write.csv(loo_summary, file.path(dirs[3], "table_s6_leave_one_out_summary.csv"), row.names = FALSE, na = "")

method_labels <- c(
  "Inverse variance weighted (multiplicative random effects)" = "IVW",
  "Weighted median" = "Weighted median", "Weighted mode" = "Weighted mode", "MR Egger" = "MR-Egger"
)
all_methods$method_short <- unname(method_labels[all_methods$method])
all_methods$label <- unname(short_labels[all_methods$outcome_key])
p_s1 <- ggplot(all_methods, aes(x = or, y = factor(label, levels = label_levels), colour = method_short)) +
  geom_vline(xintercept = 1, linetype = 2, colour = "grey50") +
  geom_errorbar(aes(xmin = or_lci95, xmax = or_uci95), orientation = "y", width = 0.12, position = position_dodge(width = 0.62)) +
  geom_point(position = position_dodge(width = 0.62), size = 1.9) + scale_x_log10() +
  labs(x = "Odds ratio (log scale)", y = NULL, colour = NULL, title = "Sensitivity estimators for total lifetime-smoking effects") +
  theme(legend.position = "top", panel.grid.minor = element_blank())
save_png_safe(file.path(dirs[4], "figure_s1_total_effects_all_estimators.png"), p_s1, 8.5, 5.2)
ggsave(file.path(dirs[4], "figure_s1_total_effects_all_estimators.pdf"), p_s1, width = 8.5, height = 5.2)

diag_long <- rbind(
  data.frame(label = diag_table$label, test = "IVW heterogeneity Q", p = diag_table$Q_pval),
  data.frame(label = diag_table$label, test = "MR-Egger intercept", p = diag_table$egger_intercept_p)
)
p_s2 <- ggplot(diag_long, aes(x = -log10(p), y = factor(label, levels = label_levels), colour = test)) +
  geom_vline(xintercept = -log10(0.05), linetype = 2, colour = "grey45") + geom_point(size = 2.5) +
  labs(x = expression(-log[10](italic(P))), y = NULL, colour = NULL, title = "Univariable MR heterogeneity and directional-pleiotropy diagnostics") +
  theme(legend.position = "top")
save_png_safe(file.path(dirs[4], "figure_s2_univariable_diagnostics.png"), p_s2, 8.2, 4.8)
ggsave(file.path(dirs[4], "figure_s2_univariable_diagnostics.pdf"), p_s2, width = 8.2, height = 4.8)

p_s3 <- ggplot(mvmr_sensitivity, aes(x = or, y = factor(label, levels = label_levels), colour = method)) +
  geom_vline(xintercept = 1, linetype = 2, colour = "grey50") +
  geom_errorbar(aes(xmin = lci, xmax = uci), orientation = "y", width = 0.12, position = position_dodge(width = 0.65)) +
  geom_point(position = position_dodge(width = 0.65), size = 1.9) + scale_x_log10() +
  labs(x = "BMI direct-effect odds ratio (log scale)", y = NULL, colour = NULL, title = "Sensitivity estimators for the conditional BMI effect") +
  theme(legend.position = "top", panel.grid.minor = element_blank())
save_png_safe(file.path(dirs[4], "figure_s3_mvmr_bmi_sensitivity.png"), p_s3, 8.5, 5.2)
ggsave(file.path(dirs[4], "figure_s3_mvmr_bmi_sensitivity.pdf"), p_s3, width = 8.5, height = 5.2)

p_s4 <- ggplot(directionality, aes(x = b, y = method, colour = direction)) +
  geom_vline(xintercept = 0, linetype = 2, colour = "grey50") +
  geom_errorbar(aes(xmin = lci, xmax = uci), orientation = "y", width = 0.15) + geom_point(size = 2.3) +
  facet_wrap(~direction, ncol = 1, scales = "free_y") +
  labs(x = "MR coefficient (95% CI)", y = NULL, colour = NULL, title = "Bidirectional MR between lifetime smoking and BMI") +
  theme(legend.position = "none")
save_png_safe(file.path(dirs[4], "figure_s4_bidirectional_smoking_bmi.png"), p_s4, 8.2, 6.0)
ggsave(file.path(dirs[4], "figure_s4_bidirectional_smoking_bmi.pdf"), p_s4, width = 8.2, height = 6.0)

p_s5 <- ggplot(loo_summary, aes(y = factor(label, levels = label_levels))) +
  geom_errorbar(aes(xmin = exp(loo_min_b), xmax = exp(loo_max_b)), orientation = "y", width = 0.16, colour = "#2166AC") +
  geom_point(aes(x = exp(full_b)), size = 2.5, colour = "#B2182B") +
  geom_vline(xintercept = 1, linetype = 2, colour = "grey50") + scale_x_log10() +
  labs(x = "Odds ratio; blue range is all leave-one-out estimates", y = NULL, title = "Leave-one-out influence analysis for total smoking effects") +
  theme(panel.grid.minor = element_blank())
save_png_safe(file.path(dirs[4], "figure_s5_leave_one_out_ranges.png"), p_s5, 8.2, 4.8)
ggsave(file.path(dirs[4], "figure_s5_leave_one_out_ranges.pdf"), p_s5, width = 8.2, height = 4.8)

writeLines(capture.output(sessionInfo()), file.path(bundle, "results", "sessionInfo_R_4.6.1.txt"))

summary_lines <- c(
  paste0("R version: ", R.version.string),
  paste0("standalone_bundle_mode=", standalone),
  paste0("A path lifetime smoking -> BMI: beta=", signif(a_ivw$b, 5), ", SE=", signif(a_ivw$se, 5), ", P=", signif(a_ivw$pval, 4)),
  "Primary inference: total effects and mutually adjusted direct effects.",
  "Exploratory indirect effects use the product-of-coefficients method and zero covariance delta approximation.",
  "Mediation proportions are suppressed when the total effect is null or the effect directions disagree.",
  paste0("Bundle: ", normalizePath(bundle, winslash = "/", mustWork = TRUE))
)
writeLines(summary_lines, file.path(bundle, "results", "analysis_summary.txt"))

manifest_files <- list.files(bundle, recursive = TRUE, full.names = TRUE)
manifest_files <- manifest_files[!grepl("artifact_manifest_(md5|sha256)\\.csv$", manifest_files)]
hashes <- unname(tools::md5sum(manifest_files))
manifest <- data.frame(
  relative_path = substring(manifest_files, nchar(bundle) + 2),
  md5 = hashes,
  bytes = file.info(manifest_files)$size
)
write.csv(manifest, file.path(bundle, "artifact_manifest_md5.csv"), row.names = FALSE)
cat(paste(summary_lines, collapse = "\n"), "\n")
