suppressPackageStartupMessages({
  library(MVMR)
  library(MendelianRandomization)
})

root <- "audit_ascii/routeA_runs"
prefix <- "lifetime_union_mvmr_cad_bmi_"
candidates <- list.dirs(root, recursive = FALSE, full.names = TRUE)
candidates <- candidates[startsWith(basename(candidates), prefix)]
if (!length(candidates)) stop("No lifetime union-MVMR run found")
run_dir <- candidates[order(file.info(candidates)[, "mtime"], decreasing = TRUE)][1]

x <- readRDS(file.path(run_dir, "mvmr_input.rds"))
bx <- as.matrix(x[, c("betaX1", "betaX2")])
bxse <- as.matrix(x[, c("sebetaX1", "sebetaX2")])
colnames(bx) <- colnames(bxse) <- c("Lifetime smoking", "BMI")

mr_input <- mr_mvinput(
  bx = bx,
  bxse = bxse,
  by = x$betaYG,
  byse = x$sebetaYG,
  exposure = c("Lifetime smoking", "BMI"),
  outcome = "Coronary heart disease",
  snps = x$SNP
)

fits <- list(
  ivw_random = mr_mvivw(mr_input, model = "random", robust = FALSE),
  ivw_random_robust = mr_mvivw(mr_input, model = "random", robust = TRUE),
  mv_egger = mr_mvegger(mr_input, orientate = 1),
  mv_median = mr_mvmedian(mr_input, iterations = 10000, seed = 20260914),
  q_minimisation_developmental = qhet_mvmr(
    x, pcor = 0, CI = FALSE, iterations = 1000, ncores = 1
  )
)

saveRDS(fits, file.path(run_dir, "robust_mvmr_sensitivity.rds"))
writeLines(
  unlist(lapply(names(fits), function(nm) {
    c(paste0("===== ", nm, " ====="), capture.output(show(fits[[nm]])), "")
  })),
  file.path(run_dir, "robust_mvmr_sensitivity.txt")
)
writeLines(capture.output(sessionInfo()), file.path(run_dir, "robust_mvmr_sessionInfo.txt"))
cat(normalizePath(run_dir, winslash = "/", mustWork = TRUE), "\n")
