suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
})

options(stringsAsFactors = FALSE)
set.seed(20260916)

root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
archive <- file.path(root, "frozen_inputs")
out <- file.path(root, "重建输出")
result_dir <- file.path(out, "results")
figure_dir <- file.path(out, "figures")
dir.create(result_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

required <- c(
  "all_outcomes_ivw_fdr.csv", "all_outcomes_all_methods.csv",
  "mvmr_bmi_outcome_panel_summary.csv", "x_to_m_mr.csv",
  "reverse_bmi_to_lifetime_mr.csv", "analysis_outcomes.csv"
)
stopifnot(all(file.exists(file.path(archive, required))))

total <- read.csv(file.path(archive, "all_outcomes_ivw_fdr.csv"), check.names = FALSE)
all_methods <- read.csv(file.path(archive, "all_outcomes_all_methods.csv"), check.names = FALSE)
mv <- read.csv(file.path(archive, "mvmr_bmi_outcome_panel_summary.csv"), check.names = FALSE)
x_to_m <- read.csv(file.path(archive, "x_to_m_mr.csv"), check.names = FALSE)
reverse_mr <- read.csv(file.path(archive, "reverse_bmi_to_lifetime_mr.csv"), check.names = FALSE)

keys <- c("cad", "pad_finngen_r5", "ais", "laa", "svs", "ces")
labels <- c(
  cad = "Coronary artery disease",
  pad_finngen_r5 = "Peripheral artery disease",
  ais = "Any ischemic stroke",
  laa = "Large-artery stroke",
  svs = "Small-vessel stroke",
  ces = "Cardioembolic stroke"
)
short <- c(
  cad = "CAD", pad_finngen_r5 = "PAD", ais = "Any ischemic stroke",
  laa = "Large-artery stroke", svs = "Small-vessel stroke", ces = "Cardioembolic stroke"
)

total <- total[match(keys, total$outcome_key), ]
mv <- mv[match(keys, mv$key), ]
stopifnot(all(total$outcome_key == mv$key))
total$p_fdr_bh <- p.adjust(total$pval, method = "BH")

direct <- data.frame(
  key = mv$key,
  outcome = unname(labels[mv$key]),
  nsnp = mv$nsnp,
  smoking_b = mv$smoking_direct_ivw,
  smoking_se = mv$se_smoking_direct_ivw,
  smoking_p = mv$p_smoking_direct_ivw,
  bmi_b = mv$bmi_direct_ivw,
  bmi_se = mv$se_bmi_direct_ivw,
  bmi_p = mv$p_bmi_direct_ivw,
  conditional_F_smoking = mv$conditional_F_smoking,
  conditional_F_bmi = mv$conditional_F_bmi,
  residual_Q = mv$Q,
  residual_Q_p = mv$Q_p
)
direct$smoking_p_fdr <- p.adjust(direct$smoking_p, method = "BH")
direct$bmi_p_fdr <- p.adjust(direct$bmi_p, method = "BH")
for (prefix in c("smoking", "bmi")) {
  direct[[paste0(prefix, "_or")]] <- exp(direct[[paste0(prefix, "_b")]])
  direct[[paste0(prefix, "_lci")]] <- exp(direct[[paste0(prefix, "_b")]] - 1.96 * direct[[paste0(prefix, "_se")]])
  direct[[paste0(prefix, "_uci")]] <- exp(direct[[paste0(prefix, "_b")]] + 1.96 * direct[[paste0(prefix, "_se")]])
}
write.csv(total, file.path(result_dir, "total_effects_verified.csv"), row.names = FALSE, na = "")
write.csv(direct, file.path(result_dir, "mvmr_direct_effects_verified_with_both_fdr.csv"), row.names = FALSE, na = "")

direction <- rbind(
  data.frame(direction = "Lifetime smoking to BMI", method = x_to_m$method,
             nsnp = x_to_m$nsnp, b = x_to_m$b, se = x_to_m$se, p = x_to_m$pval),
  data.frame(direction = "BMI to lifetime smoking", method = reverse_mr$method,
             nsnp = reverse_mr$nsnp, b = reverse_mr$b, se = reverse_mr$se, p = reverse_mr$pval)
)
direction$lci <- direction$b - 1.96 * direction$se
direction$uci <- direction$b + 1.96 * direction$se
write.csv(direction, file.path(result_dir, "bidirectional_smoking_bmi_verified.csv"), row.names = FALSE, na = "")

theme_set(theme_minimal(base_size = 11, base_family = "sans"))
blue <- "#1F4E79"
orange <- "#D97706"
red <- "#B42318"
gray <- "#667085"

save_both <- function(name, plot, width, height) {
  ggsave(file.path(figure_dir, paste0(name, ".png")), plot, width = width, height = height, dpi = 400, bg = "white")
  ggsave(file.path(figure_dir, paste0(name, ".pdf")), plot, width = width, height = height, bg = "white")
}

# Figure 1: same analytic role as Levin et al. Figure 1, redrawn for this study.
fig1 <- ggplot() +
  annotate("rect", xmin = 0.2, xmax = 2.2, ymin = 3.25, ymax = 4.15, fill = "#E8F1F8", colour = blue, linewidth = 0.7) +
  annotate("text", x = 1.2, y = 3.82, label = "Smoking instruments", fontface = "bold", size = 4.1, colour = blue) +
  annotate("text", x = 1.2, y = 3.52, label = "126 variants\nP < 5 x 10^-8; LD r2 < 0.001", size = 2.95) +
  annotate("rect", xmin = 0.2, xmax = 2.2, ymin = 1.65, ymax = 2.55, fill = "#E8F1F8", colour = blue, linewidth = 0.7) +
  annotate("text", x = 1.2, y = 2.20, label = "BMI instruments", fontface = "bold", size = 4.1, colour = blue) +
  annotate("text", x = 1.2, y = 1.90, label = "P < 5 x 10^-8; LD r2 < 0.001", size = 2.95) +
  annotate("rect", xmin = 3.0, xmax = 5.2, ymin = 3.25, ymax = 4.15, fill = "#FFF3E0", colour = orange, linewidth = 0.7) +
  annotate("text", x = 4.1, y = 3.80, label = "Lifetime smoking", fontface = "bold", size = 4.4, colour = "#9A3412") +
  annotate("text", x = 4.1, y = 3.53, label = "1-SD lifetime smoking index\nUK Biobank; N = 462,690", size = 3.25) +
  annotate("rect", xmin = 3.0, xmax = 5.2, ymin = 1.65, ymax = 2.55, fill = "#EEF4FF", colour = blue, linewidth = 0.7) +
  annotate("text", x = 4.1, y = 2.20, label = "Body mass index", fontface = "bold", size = 4.4, colour = blue) +
  annotate("text", x = 4.1, y = 1.92, label = "GIANT; N = 322,154", size = 3.25) +
  annotate("rect", xmin = 6.0, xmax = 8.75, ymin = 2.35, ymax = 4.15, fill = "#F2F4F7", colour = "#344054", linewidth = 0.7) +
  annotate("text", x = 7.375, y = 3.80, label = "Atherosclerotic outcomes", fontface = "bold", size = 4.4) +
  annotate("text", x = 7.375, y = 3.20,
           label = "Coronary artery disease\nPeripheral artery disease\nAny ischemic stroke\nLarge-artery, small-vessel,\nand cardioembolic stroke", size = 3.35, lineheight = 1.15) +
  annotate("segment", x = 2.25, xend = 2.90, y = 3.70, yend = 3.70,
           arrow = grid::arrow(length = grid::unit(0.18, "cm")), linewidth = 0.85, colour = blue) +
  annotate("segment", x = 2.25, xend = 2.90, y = 2.10, yend = 2.10,
           arrow = grid::arrow(length = grid::unit(0.18, "cm")), linewidth = 0.85, colour = blue) +
  annotate("segment", x = 5.30, xend = 5.90, y = 3.70, yend = 3.70,
           arrow = grid::arrow(length = grid::unit(0.18, "cm")), linewidth = 0.85, colour = red) +
  annotate("segment", x = 4.10, xend = 4.10, y = 3.15, yend = 2.65,
           arrow = grid::arrow(length = grid::unit(0.18, "cm")), linewidth = 0.85, colour = orange) +
  annotate("segment", x = 5.30, xend = 5.90, y = 2.10, yend = 2.55,
           arrow = grid::arrow(length = grid::unit(0.18, "cm")), linewidth = 0.85, colour = blue) +
  annotate("text", x = 5.60, y = 3.90, label = "Total effect", size = 3.2, colour = red) +
  annotate("text", x = 4.42, y = 2.88, label = "A path", size = 3.1, colour = orange) +
  annotate("text", x = 5.62, y = 2.08, label = "MVMR direct effects", size = 3.1, colour = blue) +
  annotate("rect", xmin = 0.35, xmax = 8.65, ymin = 0.35, ymax = 1.15, fill = "white", colour = "#98A2B3", linetype = 2) +
  annotate("text", x = 4.5, y = 0.91, label = "Core assumptions", fontface = "bold", size = 3.8) +
  annotate("text", x = 4.5, y = 0.62,
           label = "Instrument relevance • independence from confounders • no unmodelled path to outcome", size = 3.25) +
  coord_cartesian(xlim = c(0, 9), ylim = c(0.2, 4.5), clip = "off") +
  labs(title = "Study design and Mendelian randomization framework") +
  theme_void(base_family = "sans") +
  theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 14, margin = margin(b = 10)))
save_both("figure1_study_design_levin_template", fig1, 8.6, 5.0)

# Figure 2A: primary total effects.
total_plot <- data.frame(
  key = total$outcome_key,
  outcome = unname(labels[total$outcome_key]),
  or = exp(total$b),
  lci = exp(total$b - 1.96 * total$se),
  uci = exp(total$b + 1.96 * total$se),
  fdr = total$p_fdr_bh
)
outcome_levels <- rev(unname(labels[keys]))
p2a <- ggplot(total_plot, aes(or, factor(outcome, levels = outcome_levels))) +
  geom_vline(xintercept = 1, linetype = 2, colour = "#98A2B3") +
  geom_errorbar(aes(xmin = lci, xmax = uci), orientation = "y", width = 0.16, colour = "#344054") +
  geom_point(aes(fill = fdr < 0.05), shape = 21, size = 3.1, colour = "white", stroke = 0.5) +
  scale_fill_manual(values = c(`TRUE` = red, `FALSE` = gray), guide = "none") +
  scale_x_log10(breaks = c(0.8, 1, 1.5, 2, 3, 4)) +
  labs(title = "A  Total association with vascular outcomes", x = "Odds ratio per 1-SD higher lifetime smoking index", y = NULL) +
  theme(panel.grid.minor = element_blank(), plot.title = element_text(face = "bold"))

# Figure 2B: SNP scatter plots with the same estimator families used in the source article.
harm <- do.call(rbind, lapply(keys, function(k) {
  d <- read.csv(file.path(archive, paste0(k, "_harmonised.csv")), check.names = FALSE)
  d <- d[d$mr_keep %in% TRUE & is.finite(d$beta.exposure) & is.finite(d$beta.outcome), ]
  data.frame(key = k, panel = unname(short[k]), bx = d$beta.exposure, by = d$beta.outcome)
}))
methods_keep <- c("Inverse variance weighted (multiplicative random effects)", "Weighted median", "MR Egger")
slopes <- all_methods[all_methods$method %in% methods_keep, c("outcome_key", "method", "b")]
slopes$panel <- unname(short[slopes$outcome_key])
slopes$intercept <- 0
egger_int <- read.csv(file.path(archive, "all_outcomes_egger_intercept.csv"), check.names = FALSE)
idx <- slopes$method == "MR Egger"
slopes$intercept[idx] <- egger_int$egger_intercept[match(slopes$outcome_key[idx], egger_int$outcome_key)]
slopes$method <- factor(slopes$method, levels = methods_keep,
                        labels = c("IVW", "Weighted median", "MR-Egger"))
p2b <- ggplot(harm, aes(bx, by)) +
  geom_hline(yintercept = 0, colour = "#D0D5DD", linewidth = 0.3) +
  geom_vline(xintercept = 0, colour = "#D0D5DD", linewidth = 0.3) +
  geom_point(size = 0.8, alpha = 0.45, colour = "#475467") +
  geom_abline(data = slopes, aes(slope = b, intercept = intercept, colour = method), linewidth = 0.65) +
  facet_wrap(~factor(panel, levels = unname(short[keys])), scales = "free", ncol = 3) +
  scale_colour_manual(values = c("IVW" = red, "Weighted median" = blue, "MR-Egger" = orange)) +
  labs(title = "B  Variant-level associations and sensitivity estimators",
       x = "Variant association with lifetime smoking index", y = "Variant log-odds association with outcome", colour = NULL) +
  theme(panel.grid.minor = element_blank(), legend.position = "top", plot.title = element_text(face = "bold"),
        strip.text = element_text(face = "bold", size = 8.5))
fig2 <- p2a / p2b + plot_layout(heights = c(0.82, 1.75)) +
  plot_annotation(title = "Total effects of lifetime smoking across vascular beds",
                  theme = theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 14)))
save_both("figure2_total_effects_and_scatter", fig2, 9.0, 10.0)

# Figure 3: same analytic role as Levin et al. Figure 3, adapted to the BMI pathway available here.
method_order <- c("Inverse variance weighted (multiplicative random effects)", "Weighted median", "Weighted mode", "MR Egger")
direction$method_short <- factor(direction$method, levels = method_order,
                                 labels = c("IVW", "Weighted median", "Weighted mode", "MR-Egger"))
p3 <- ggplot(direction, aes(b, method_short, colour = direction)) +
  geom_vline(xintercept = 0, linetype = 2, colour = "#98A2B3") +
  geom_errorbar(aes(xmin = lci, xmax = uci), orientation = "y", width = 0.18, linewidth = 0.7) +
  geom_point(size = 3) +
  facet_wrap(~direction, scales = "free_x", ncol = 2) +
  scale_colour_manual(values = c("Lifetime smoking to BMI" = red, "BMI to lifetime smoking" = blue), guide = "none") +
  labs(title = "Bidirectional associations between lifetime smoking and body mass index",
       subtitle = "Points are beta estimates; bars are 95% confidence intervals",
       x = "MR estimate", y = NULL) +
  theme(panel.grid.minor = element_blank(), plot.title = element_text(hjust = 0.5, face = "bold"),
        strip.text = element_text(face = "bold"))
save_both("figure3_bidirectional_smoking_bmi", p3, 8.8, 4.8)

# Figure 4A mirrors the source paper's total-vs-adjusted smoking comparison; panel B reports BMI direct effects.
comparison <- rbind(
  data.frame(key = total$outcome_key, outcome = unname(labels[total$outcome_key]), model = "Total smoking effect",
             or = exp(total$b), lci = exp(total$b - 1.96 * total$se), uci = exp(total$b + 1.96 * total$se),
             fdr = total$p_fdr_bh),
  data.frame(key = direct$key, outcome = direct$outcome, model = "Smoking direct effect (adjusted for BMI)",
             or = direct$smoking_or, lci = direct$smoking_lci, uci = direct$smoking_uci, fdr = direct$smoking_p_fdr)
)
p4a <- ggplot(comparison, aes(or, factor(outcome, levels = outcome_levels), colour = model)) +
  geom_vline(xintercept = 1, linetype = 2, colour = "#98A2B3") +
  geom_errorbar(aes(xmin = lci, xmax = uci), orientation = "y", width = 0.15,
                position = position_dodge(width = 0.50)) +
  geom_point(aes(shape = fdr < 0.05), position = position_dodge(width = 0.50), size = 2.7) +
  scale_colour_manual(values = c("Total smoking effect" = gray, "Smoking direct effect (adjusted for BMI)" = red)) +
  scale_shape_manual(values = c(`TRUE` = 16, `FALSE` = 1), labels = c(`FALSE` = "No", `TRUE` = "Yes"), name = "BH-FDR <0.05") +
  guides(shape = guide_legend(order = 1), colour = guide_legend(order = 2)) +
  scale_x_log10(breaks = c(0.8, 1, 1.5, 2, 3, 4)) +
  labs(title = "A  Smoking effects before and after adjustment for BMI", x = "Odds ratio", y = NULL, colour = NULL) +
  theme(panel.grid.minor = element_blank(), legend.position = "top", plot.title = element_text(face = "bold"))

bmi_plot <- data.frame(outcome = direct$outcome, or = direct$bmi_or, lci = direct$bmi_lci,
                       uci = direct$bmi_uci, fdr = direct$bmi_p_fdr)
p4b <- ggplot(bmi_plot, aes(or, factor(outcome, levels = outcome_levels))) +
  geom_vline(xintercept = 1, linetype = 2, colour = "#98A2B3") +
  geom_errorbar(aes(xmin = lci, xmax = uci), orientation = "y", width = 0.15, colour = blue) +
  geom_point(aes(shape = fdr < 0.05), size = 2.8, colour = blue) +
  scale_shape_manual(values = c(`TRUE` = 16, `FALSE` = 1), guide = "none") +
  scale_x_log10(breaks = c(0.8, 1, 1.5, 2, 3)) +
  labs(title = "B  BMI direct effects adjusted for lifetime smoking", x = "Odds ratio", y = NULL) +
  theme(panel.grid.minor = element_blank(), plot.title = element_text(face = "bold"))
fig4 <- p4a / p4b + plot_layout(heights = c(1.1, 1)) +
  plot_annotation(title = "Direct effects in multivariable Mendelian randomization",
                  theme = theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 14)))
save_both("figure4_total_vs_direct_mvmr", fig4, 9.0, 8.3)

summary_lines <- c(
  R.version.string,
  paste0("Run time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "Primary total effects recalculated from frozen local GWAS associations.",
  "BH-FDR was recalculated separately for six total smoking effects, six smoking direct effects, and six BMI direct effects.",
  paste0("Smoking direct BH-FDR: ", paste(sprintf("%s=%.6g", direct$key, direct$smoking_p_fdr), collapse = "; ")),
  paste0("BMI direct BH-FDR: ", paste(sprintf("%s=%.6g", direct$key, direct$bmi_p_fdr), collapse = "; ")),
  paste0("Conditional F ranges: smoking ", sprintf("%.1f–%.1f", min(direct$conditional_F_smoking), max(direct$conditional_F_smoking)),
         "; BMI ", sprintf("%.1f–%.1f", min(direct$conditional_F_bmi), max(direct$conditional_F_bmi))),
  "All figures were generated from the frozen local archive; no API access was used."
)
writeLines(summary_lines, file.path(result_dir, "R_4.6.1_verification_summary.txt"), useBytes = TRUE)
writeLines(capture.output(sessionInfo()), file.path(result_dir, "sessionInfo.txt"), useBytes = TRUE)

cat(paste(summary_lines, collapse = "\n"), "\n")
