suppressPackageStartupMessages(library(MRPRESSO))

set.seed(20260914)
root <- "audit_ascii/routeA_runs"
prefix <- "lifetime_smoking_primary_outcomes_"
candidates <- list.dirs(root, recursive = FALSE, full.names = TRUE)
candidates <- candidates[startsWith(basename(candidates), prefix)]
stopifnot(length(candidates) > 0L)
run_dir <- candidates[order(file.info(candidates)$mtime, decreasing = TRUE)][1]

outcomes <- read.csv(file.path(run_dir, "analysis_outcomes.csv"), stringsAsFactors = FALSE)
requested_keys <- commandArgs(trailingOnly = TRUE)
if (length(requested_keys)) {
  stopifnot(all(requested_keys %in% outcomes$outcome_key))
  outcomes <- outcomes[outcomes$outcome_key %in% requested_keys, , drop = FALSE]
}
simulations <- 3000L
summaries <- list()

first_or_na <- function(x, column) {
  if (is.null(x) || !is.data.frame(x) || nrow(x) == 0L || !column %in% names(x)) {
    return(NA_real_)
  }
  as.numeric(x[[column]][1])
}

for (key in outcomes$outcome_key) {
  message("MR-PRESSO: ", key)
  dat <- readRDS(file.path(run_dir, paste0(key, "_harmonised.rds")))
  dat <- dat[dat$mr_keep & complete.cases(
    dat[, c("beta.outcome", "beta.exposure", "se.outcome", "se.exposure")]
  ), , drop = FALSE]
  stopifnot(nrow(dat) >= 4L)

  fit <- mr_presso(
    BetaOutcome = "beta.outcome",
    BetaExposure = "beta.exposure",
    SdOutcome = "se.outcome",
    SdExposure = "se.exposure",
    data = dat,
    OUTLIERtest = TRUE,
    DISTORTIONtest = TRUE,
    SignifThreshold = 0.05,
    NbDistribution = simulations,
    seed = 20260914
  )
  saveRDS(fit, file.path(run_dir, paste0(key, "_mr_presso_3000.rds")))
  writeLines(
    capture.output(print(fit)),
    file.path(run_dir, paste0(key, "_mr_presso_3000.txt"))
  )

  main <- fit[["Main MR results"]]
  global <- fit[["MR-PRESSO results"]][["Global Test"]]
  distortion <- fit[["MR-PRESSO results"]][["Distortion Test"]]
  corrected <- main[main$`MR Analysis` == "Outlier-corrected", , drop = FALSE]
  raw <- main[main$`MR Analysis` == "Raw", , drop = FALSE]

  idx <- if (!is.null(distortion)) distortion[["Outliers Indices"]] else integer(0)
  idx <- if (is.numeric(idx)) idx else integer(0)
  idx <- idx[is.finite(idx) & idx >= 1L & idx <= nrow(dat)]
  outlier_names <- dat$SNP[idx]
  summaries[[key]] <- data.frame(
    outcome_key = key,
    nsnp = nrow(dat),
    global_rss = unname(global$RSSobs),
    global_p = unname(global$Pvalue),
    outlier_count = length(outlier_names),
    outlier_snps = paste(outlier_names, collapse = ";"),
    raw_beta = first_or_na(raw, "Causal Estimate"),
    raw_se = first_or_na(raw, "Sd"),
    raw_p = first_or_na(raw, "P-value"),
    corrected_beta = first_or_na(corrected, "Causal Estimate"),
    corrected_se = first_or_na(corrected, "Sd"),
    corrected_p = first_or_na(corrected, "P-value"),
    distortion_percent = if (!is.null(distortion)) as.numeric(distortion[["Distortion Coefficient"]]) else NA_real_,
    distortion_p = if (!is.null(distortion)) as.numeric(distortion[["Pvalue"]]) else NA_real_,
    simulations = simulations,
    stringsAsFactors = FALSE
  )
}

summary <- do.call(rbind, summaries)
rownames(summary) <- NULL
key_tag <- paste(outcomes$outcome_key, collapse = "_")
write.csv(
  summary,
  file.path(run_dir, paste0("mr_presso_panel_summary_", key_tag, ".csv")),
  row.names = FALSE, na = ""
)
writeLines(
  capture.output(sessionInfo()),
  file.path(run_dir, paste0("mr_presso_sessionInfo_", key_tag, ".txt"))
)
print(summary)
cat("run_dir=", normalizePath(run_dir, winslash = "/", mustWork = TRUE), "\n", sep = "")
