options(stringsAsFactors=FALSE)
stopifnot(as.character(getRversion()) == '4.6.1')
suppressPackageStartupMessages({library(TwoSampleMR); library(MVMR)})
root <- normalizePath(getwd(), winslash='/')
archive <- if (dir.exists(file.path(root,'frozen_inputs'))) file.path(root,'frozen_inputs') else file.path(root, '02_代码与复现/完整可复现分析包/data_archive')
out <- if (dir.exists(file.path(root,'frozen_inputs'))) file.path(root,'results') else file.path(root, '02_代码与复现/01稿_双语同步校核_20260916/results')
dir.create(out, recursive=TRUE, showWarnings=FALSE)
old_total <- read.csv(file.path(archive,'all_outcomes_ivw_fdr.csv'))
old_mv <- read.csv(file.path(archive,'mvmr_bmi_outcome_panel_summary.csv'))
keys <- c('cad','pad_finngen_r5','ais','laa','svs','ces')
checks <- list(); vals <- list()
for (k in keys) {
  d <- read.csv(file.path(archive,paste0(k,'_harmonised.csv')))
  d <- d[d$mr_keep %in% TRUE,]
  fit <- TwoSampleMR::mr_ivw_mre(d$beta.exposure,d$beta.outcome,d$se.exposure,d$se.outcome)
  m <- readRDS(file.path(archive,paste0(k,'_mvmr_input.rds')))
  mv <- MVMR::ivw_mvmr(m, gencov=0)
  f <- MVMR::strength_mvmr(m,gencov=0)
  saveRDS(list(total=fit,mvmr=mv,conditional_F=f),file.path(out,paste0(k,'_refit.rds')))
  a <- old_total[old_total$outcome_key==k,]; b <- old_mv[old_mv$key==k,]
  delta <- max(abs(c(fit$b-a$b,fit$se-a$se,fit$pval-a$pval,
                     mv[1,1]-b$smoking_direct_ivw,mv[1,2]-b$se_smoking_direct_ivw,mv[1,4]-b$p_smoking_direct_ivw,
                     mv[2,1]-b$bmi_direct_ivw,mv[2,2]-b$se_bmi_direct_ivw,mv[2,4]-b$p_bmi_direct_ivw)))
  checks[[k]] <- data.frame(outcome=k,max_abs_difference=delta,pass=delta<1e-10)
  vals[[k]] <- data.frame(outcome=k,total_b=fit$b,total_se=fit$se,total_p=fit$pval,
    smoking_b=mv[1,1],smoking_se=mv[1,2],smoking_p=mv[1,4],bmi_b=mv[2,1],bmi_se=mv[2,2],bmi_p=mv[2,4])
}
checks <- do.call(rbind,checks); vals <- do.call(rbind,vals)
for (p in c('total','smoking','bmi')) vals[[paste0(p,'_fdr')]] <- p.adjust(vals[[paste0(p,'_p')]],'BH')
write.csv(checks,file.path(out,'refit_comparison.csv'),row.names=FALSE)
write.csv(vals,file.path(out,'refitted_results.csv'),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
stopifnot(all(checks$pass))
print(checks); print(vals[,c('outcome','smoking_fdr','bmi_fdr')])
cat('All six UVMR and MVMR models refitted successfully from archived SNP-level inputs.\n')
