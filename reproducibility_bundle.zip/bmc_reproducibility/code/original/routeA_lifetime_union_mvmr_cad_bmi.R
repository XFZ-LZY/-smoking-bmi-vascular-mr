suppressPackageStartupMessages({
  library(data.table)
  library(TwoSampleMR)
  library(MVMR)
})

options(timeout = 1200)
set.seed(20260914)
jwt <- Sys.getenv("OPENGWAS_JWT")
stopifnot(nchar(jwt) > 100)

root <- "audit_ascii/routeA_runs"
dir.create(root, recursive = TRUE, showWarnings = FALSE)
run_id <- format(Sys.time(), "%Y%m%d_%H%M%S")
outdir <- file.path(root, paste0("lifetime_union_mvmr_cad_bmi_", run_id))
dir.create(outdir, recursive = TRUE, showWarnings = FALSE)

ids <- c(
  exposure = "Wootton2019_lifetime_smoking",
  mediator = "ieu-a-835",
  outcome = "ieu-a-7"
)
write.csv(data.frame(role = names(ids), id = unname(ids)),
          file.path(outdir, "analysis_ids.csv"), row.names = FALSE)

save_csv_rds <- function(x, stem) {
  saveRDS(x, file.path(outdir, paste0(stem, ".rds")))
  if (is.data.frame(x) || is.matrix(x)) {
    write.csv(x, file.path(outdir, paste0(stem, ".csv")), row.names = FALSE, na = "")
  }
}

sd_lifetime <- 0.6940093
gws_file <- "audit_ascii/Wootton2019_lifetime_smoking_GWS_126.txt"
full_file <- "audit_ascii/Wootton2019_lifetime_smoking_full.txt"

to_exposure <- function(d, phenotype, id) {
  raw <- data.frame(
    SNP = d$SNP,
    beta = as.numeric(d$BETA) / sd_lifetime,
    se = as.numeric(d$SE) / sd_lifetime,
    effect_allele = toupper(d$EFFECT_ALLELE),
    other_allele = toupper(d$OTHER_ALLELE),
    eaf = as.numeric(d$EAF),
    pval = as.numeric(d$P),
    samplesize = 462690,
    phenotype = phenotype,
    stringsAsFactors = FALSE
  )
  z <- format_data(
    raw, type = "exposure", snp_col = "SNP", beta_col = "beta",
    se_col = "se", effect_allele_col = "effect_allele",
    other_allele_col = "other_allele", eaf_col = "eaf",
    pval_col = "pval", samplesize_col = "samplesize",
    phenotype_col = "phenotype"
  )
  z$id.exposure <- id
  z$exposure <- phenotype
  z
}

gws <- fread(gws_file, data.table = FALSE)
stopifnot(nrow(gws) == 126L, !anyDuplicated(gws$SNP))
life_inst <- to_exposure(
  gws, "Lifetime smoking index per 1 SD (Wootton et al. 2019)",
  ids[["exposure"]]
)

bmi_inst <- extract_instruments(
  outcomes = ids[["mediator"]], p1 = 5e-8, clump = TRUE,
  r2 = 0.001, kb = 10000, opengwas_jwt = jwt
)
stopifnot(nrow(bmi_inst) >= 3L)
save_csv_rds(life_inst, "lifetime_smoking_instruments_126")
save_csv_rds(bmi_inst, "bmi_instruments_initial")

candidate <- rbind(
  data.frame(
    SNP = life_inst$SNP, pval.exposure = life_inst$pval.exposure,
    reference_effect_allele = life_inst$effect_allele.exposure,
    reference_other_allele = life_inst$other_allele.exposure,
    instrument_source = "lifetime_smoking"
  ),
  data.frame(
    SNP = bmi_inst$SNP, pval.exposure = bmi_inst$pval.exposure,
    reference_effect_allele = bmi_inst$effect_allele.exposure,
    reference_other_allele = bmi_inst$other_allele.exposure,
    instrument_source = "BMI"
  )
)
candidate <- candidate[order(candidate$pval.exposure), ]
candidate <- candidate[!duplicated(candidate$SNP), ]
candidate$id.exposure <- "joint"
candidate$exposure <- "Lifetime smoking plus BMI instrument candidates"
joint_clumped <- clump_data(
  candidate, clump_kb = 10000, clump_r2 = 0.001,
  clump_p1 = 5e-8, pop = "EUR"
)
stopifnot(nrow(joint_clumped) >= 3L)
save_csv_rds(candidate, "joint_candidates_before_cross_exposure_clump")
save_csv_rds(joint_clumped, "joint_candidates_after_cross_exposure_clump")

message("Reading the complete lifetime-smoking GWAS with data.table::fread")
full <- fread(
  full_file,
  select = c("SNP", "EFFECT_ALLELE", "OTHER_ALLELE", "EAF", "INFO", "BETA", "SE", "P"),
  data.table = FALSE,
  showProgress = TRUE
)
target <- joint_clumped[, c(
  "SNP", "reference_effect_allele", "reference_other_allele", "instrument_source"
)]
full_matches <- merge(target, full, by = "SNP", all.x = TRUE, sort = FALSE)
full_matches$allele_match <- with(
  full_matches,
  (EFFECT_ALLELE == reference_effect_allele & OTHER_ALLELE == reference_other_allele) |
    (EFFECT_ALLELE == reference_other_allele & OTHER_ALLELE == reference_effect_allele)
)
matched_snps <- unique(full_matches$SNP[full_matches$allele_match %in% TRUE])
missing_life <- setdiff(joint_clumped$SNP, matched_snps)
writeLines(missing_life, file.path(outdir, "joint_snps_missing_from_lifetime_gwas.txt"))
life_union_raw <- full_matches[full_matches$allele_match %in% TRUE, , drop = FALSE]
life_union_raw <- life_union_raw[order(life_union_raw$SNP, -life_union_raw$INFO), , drop = FALSE]
life_union_raw <- life_union_raw[!duplicated(life_union_raw$SNP), , drop = FALSE]
life_union_raw <- life_union_raw[, names(full), drop = FALSE]
life_union <- to_exposure(
  life_union_raw,
  "Lifetime smoking index per 1 SD (Wootton et al. 2019)",
  ids[["exposure"]]
)
save_csv_rds(life_union_raw, "lifetime_smoking_associations_for_joint_snps_raw")
save_csv_rds(life_union, "lifetime_smoking_associations_for_joint_snps_formatted")

bmi_union <- extract_outcome_data(
  snps = life_union$SNP, outcomes = ids[["mediator"]],
  proxies = TRUE, rsq = 0.8, align_alleles = 1, palindromes = 1,
  maf_threshold = 0.3, opengwas_jwt = jwt
)
save_csv_rds(bmi_union, "bmi_associations_for_joint_snps_raw")

pair <- harmonise_data(life_union, bmi_union, action = 2)
pair <- pair[pair$mr_keep, , drop = FALSE]
tab <- table(pair$SNP)
pair <- pair[pair$SNP %in% names(tab)[tab == 1L], , drop = FALSE]
save_csv_rds(pair, "lifetime_bmi_harmonised_joint_snps")

life_rows <- pair[, c(
  "SNP", "exposure", "id.exposure", "effect_allele.exposure",
  "other_allele.exposure", "eaf.exposure", "beta.exposure",
  "se.exposure", "pval.exposure"
)]
bmi_rows <- pair[, c(
  "SNP", "outcome", "id.outcome", "effect_allele.outcome",
  "other_allele.outcome", "eaf.outcome", "beta.outcome",
  "se.outcome", "pval.outcome"
)]
names(bmi_rows) <- gsub("outcome", "exposure", names(bmi_rows))
mv_exp <- rbind(life_rows, bmi_rows)
save_csv_rds(mv_exp, "mvmr_exposure_union_harmonised")

cad_union <- extract_outcome_data(
  snps = unique(mv_exp$SNP), outcomes = ids[["outcome"]],
  proxies = TRUE, rsq = 0.8, align_alleles = 1, palindromes = 1,
  maf_threshold = 0.3, opengwas_jwt = jwt
)
save_csv_rds(cad_union, "cad_associations_for_joint_snps_raw")

mv_dat <- mv_harmonise_data(mv_exp, cad_union, harmonise_strictness = 2)
mv_fit <- mv_multiple(
  mv_dat, intercept = FALSE, instrument_specific = FALSE,
  pval_threshold = 5e-8, plots = FALSE
)
saveRDS(mv_dat, file.path(outdir, "mvmr_harmonised.rds"))
saveRDS(mv_fit, file.path(outdir, "mvmr_twosamplemr_fit.rds"))
save_csv_rds(mv_fit$result, "mvmr_twosamplemr_result")

bx <- mv_dat$exposure_beta
bxse <- mv_dat$exposure_se
by <- as.numeric(mv_dat$outcome_beta)
byse <- as.numeric(mv_dat$outcome_se)
rsid <- rownames(bx)
if (is.null(rsid)) rsid <- paste0("variant_", seq_len(nrow(bx)))
mvmr_input <- format_mvmr(
  BXGs = bx, BYG = by, seBXGs = bxse, seBYG = byse, RSID = rsid
)
saveRDS(mvmr_input, file.path(outdir, "mvmr_input.rds"))
ivw_mv <- ivw_mvmr(mvmr_input, gencov = 0)
cond_f <- strength_mvmr(mvmr_input, gencov = 0)
q_stat <- pleiotropy_mvmr(mvmr_input, gencov = 0)
save_csv_rds(ivw_mv, "mvmr_ivw")
writeLines(capture.output(print(cond_f)), file.path(outdir, "mvmr_conditional_F.txt"))
writeLines(capture.output(print(q_stat)), file.path(outdir, "mvmr_Q.txt"))
saveRDS(cond_f, file.path(outdir, "mvmr_conditional_F.rds"))
saveRDS(q_stat, file.path(outdir, "mvmr_Q.rds"))

cad_life <- extract_outcome_data(
  snps = life_inst$SNP, outcomes = ids[["outcome"]],
  proxies = TRUE, rsq = 0.8, align_alleles = 1, palindromes = 1,
  maf_threshold = 0.3, opengwas_jwt = jwt
)
bmi_life <- extract_outcome_data(
  snps = life_inst$SNP, outcomes = ids[["mediator"]],
  proxies = TRUE, rsq = 0.8, align_alleles = 1, palindromes = 1,
  maf_threshold = 0.3, opengwas_jwt = jwt
)
save_csv_rds(cad_life, "cad_associations_for_lifetime_instruments_raw")
save_csv_rds(bmi_life, "bmi_associations_for_lifetime_instruments_raw")
life_xy <- harmonise_data(life_inst, cad_life, action = 2)
life_xy <- life_xy[life_xy$mr_keep, , drop = FALSE]
life_xm <- harmonise_data(life_inst, bmi_life, action = 2)
life_xm <- life_xm[life_xm$mr_keep, , drop = FALSE]
uv_methods <- c("mr_ivw_mre", "mr_weighted_median", "mr_weighted_mode", "mr_egger_regression")
xy_res <- mr(life_xy, method_list = uv_methods)
xm_res <- mr(life_xm, method_list = uv_methods)
save_csv_rds(life_xy, "x_to_y_harmonised")
save_csv_rds(life_xm, "x_to_m_harmonised")
save_csv_rds(xy_res, "x_to_y_mr")
save_csv_rds(xm_res, "x_to_m_mr")

ivw_row <- function(x) {
  z <- x[x$method == "Inverse variance weighted (multiplicative random effects)", ]
  stopifnot(nrow(z) == 1L)
  z
}
total <- ivw_row(xy_res)
a_path <- ivw_row(xm_res)
b_path <- unname(ivw_mv[2, "Estimate"])
se_b <- unname(ivw_mv[2, "Std. Error"])
indirect <- a_path$b * b_path
se_indirect <- sqrt(b_path^2 * a_path$se^2 + a_path$b^2 * se_b^2)
p_indirect <- 2 * pnorm(abs(indirect / se_indirect), lower.tail = FALSE)

mediation <- data.frame(
  a = a_path$b, se_a = a_path$se,
  b_conditional = b_path, se_b_conditional = se_b,
  total_effect = total$b, se_total_effect = total$se,
  indirect_effect = indirect, se_indirect_zero_cov = se_indirect,
  indirect_lci = indirect - 1.96 * se_indirect,
  indirect_uci = indirect + 1.96 * se_indirect,
  p_indirect = p_indirect,
  proportion_mediated = indirect / total$b,
  conditional_F_smoking = unname(cond_f[1, 1]),
  conditional_F_bmi = unname(cond_f[1, 2]),
  covariance_assumption = "Covariance between SNP effects on the two exposures fixed to zero",
  stringsAsFactors = FALSE
)
save_csv_rds(mediation, "mediation_product")

summary_lines <- c(
  paste0("run_id=", run_id),
  paste0("output_dir=", normalizePath(outdir, winslash = "/", mustWork = TRUE)),
  paste0("lifetime instruments=", nrow(life_inst), "; BMI instruments=", nrow(bmi_inst)),
  paste0("unique candidates before cross-exposure clump=", nrow(candidate)),
  paste0("joint candidates after cross-exposure clump=", nrow(joint_clumped)),
  paste0("joint SNPs absent from full lifetime GWAS=", length(missing_life)),
  paste0("harmonised two-exposure SNPs before CAD harmonisation=", length(unique(mv_exp$SNP))),
  paste0("MVMR complete-case SNPs=", nrow(bx)),
  paste0("conditional F smoking=", signif(mediation$conditional_F_smoking, 8),
         "; BMI=", signif(mediation$conditional_F_bmi, 8)),
  paste0("BMI conditional beta=", signif(b_path, 8), "; SE=", signif(se_b, 8)),
  paste0("indirect beta=", signif(indirect, 8), "; 95% CI=",
         signif(mediation$indirect_lci, 8), " to ", signif(mediation$indirect_uci, 8),
         "; P=", signif(p_indirect, 8)),
  "Exposure-effect covariance is unknown and fixed to zero; report this limitation."
)
writeLines(summary_lines, file.path(outdir, "run_summary.txt"))
writeLines(capture.output(sessionInfo()), file.path(outdir, "sessionInfo.txt"))
cat(paste(summary_lines, collapse = "\n"), "\n")
