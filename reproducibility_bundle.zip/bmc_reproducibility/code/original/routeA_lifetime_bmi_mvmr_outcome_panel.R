suppressPackageStartupMessages({
  library(TwoSampleMR)
  library(MVMR)
  library(MendelianRandomization)
})

options(timeout = 1200)
set.seed(20260914)
jwt <- Sys.getenv("OPENGWAS_JWT")
stopifnot(nchar(jwt) > 100)

root <- "audit_ascii/routeA_runs"
source_run <- file.path(root, "lifetime_union_mvmr_cad_bmi_20260914_065950")
total_run <- file.path(root, "lifetime_smoking_primary_outcomes_20260914_105437")
stopifnot(dir.exists(source_run), dir.exists(total_run))

run_id <- format(Sys.time(), "%Y%m%d_%H%M%S")
outdir <- file.path(root, paste0("lifetime_bmi_mvmr_outcome_panel_", run_id))
dir.create(outdir, recursive = TRUE, showWarnings = FALSE)

outcomes <- data.frame(
  key = c("cad", "pad_finngen_r5", "ais", "laa", "svs", "ces"),
  id = c("ieu-a-7", "finn-b-I9_PAD", "ebi-a-GCST005843", "ebi-a-GCST005840", "ebi-a-GCST005841", "ebi-a-GCST005842"),
  label = c(
    "Coronary artery disease",
    "Peripheral artery disease (FinnGen R5)",
    "Any ischemic stroke (MEGASTROKE European)",
    "Large-artery stroke (MEGASTROKE European)",
    "Small-vessel stroke (MEGASTROKE European)",
    "Cardioembolic stroke (MEGASTROKE European)"
  ),
  stringsAsFactors = FALSE
)
write.csv(outcomes, file.path(outdir, "analysis_outcomes.csv"), row.names = FALSE)

save_csv_rds <- function(x, stem) {
  saveRDS(x, file.path(outdir, paste0(stem, ".rds")))
  if (is.data.frame(x) || is.matrix(x)) {
    write.csv(x, file.path(outdir, paste0(stem, ".csv")), row.names = FALSE, na = "")
  }
}

mv_exp <- readRDS(file.path(source_run, "mvmr_exposure_union_harmonised.rds"))
stopifnot(length(unique(mv_exp$SNP)) >= 3L)
save_csv_rds(mv_exp, "mvmr_exposure_union_harmonised")

x_to_m <- read.csv(file.path(source_run, "x_to_m_mr.csv"), stringsAsFactors = FALSE)
a_row <- x_to_m[x_to_m$method == "Inverse variance weighted (multiplicative random effects)", ]
stopifnot(nrow(a_row) == 1L)
a_path <- a_row$b
se_a <- a_row$se

totals <- read.csv(file.path(total_run, "all_outcomes_ivw_fdr.csv"), stringsAsFactors = FALSE)

fit_one <- function(key, id, label, index) {
  message("Extracting ", label, " (", id, ")")
  outcome_raw <- extract_outcome_data(
    snps = unique(mv_exp$SNP), outcomes = id,
    proxies = TRUE, rsq = 0.8, align_alleles = 1,
    palindromes = 1, maf_threshold = 0.3,
    opengwas_jwt = jwt
  )
  save_csv_rds(outcome_raw, paste0(key, "_outcome_associations_raw"))

  mv_dat <- mv_harmonise_data(mv_exp, outcome_raw, harmonise_strictness = 2)
  saveRDS(mv_dat, file.path(outdir, paste0(key, "_mvmr_harmonised.rds")))

  bx <- mv_dat$exposure_beta
  bxse <- mv_dat$exposure_se
  by <- as.numeric(mv_dat$outcome_beta)
  byse <- as.numeric(mv_dat$outcome_se)
  rsid <- rownames(bx)
  if (is.null(rsid)) rsid <- paste0("variant_", seq_len(nrow(bx)))
  stopifnot(nrow(bx) >= 3L, length(by) == nrow(bx))

  mvmr_input <- format_mvmr(
    BXGs = bx, BYG = by, seBXGs = bxse, seBYG = byse, RSID = rsid
  )
  saveRDS(mvmr_input, file.path(outdir, paste0(key, "_mvmr_input.rds")))
  ivw <- ivw_mvmr(mvmr_input, gencov = 0)
  cond_f <- strength_mvmr(mvmr_input, gencov = 0)
  q_stat <- pleiotropy_mvmr(mvmr_input, gencov = 0)
  save_csv_rds(ivw, paste0(key, "_mvmr_ivw"))
  saveRDS(cond_f, file.path(outdir, paste0(key, "_conditional_F.rds")))
  saveRDS(q_stat, file.path(outdir, paste0(key, "_Q.rds")))
  writeLines(capture.output(print(cond_f)), file.path(outdir, paste0(key, "_conditional_F.txt")))
  writeLines(capture.output(print(q_stat)), file.path(outdir, paste0(key, "_Q.txt")))

  mr_input <- mr_mvinput(
    bx = bx, bxse = bxse, by = by, byse = byse,
    exposure = c("Lifetime smoking", "BMI"), outcome = label, snps = rsid
  )
  fits <- list(
    ivw_random = mr_mvivw(mr_input, model = "random", robust = FALSE),
    ivw_random_robust = mr_mvivw(mr_input, model = "random", robust = TRUE),
    mv_egger = mr_mvegger(mr_input, orientate = 1),
    mv_median = mr_mvmedian(mr_input, iterations = 10000, seed = 20260914 + index)
  )
  saveRDS(fits, file.path(outdir, paste0(key, "_robust_mvmr_fits.rds")))
  writeLines(
    unlist(lapply(names(fits), function(nm) {
      c(paste0("===== ", nm, " ====="), capture.output(show(fits[[nm]])), "")
    })),
    file.path(outdir, paste0(key, "_robust_mvmr_fits.txt"))
  )

  b_path <- unname(ivw[2, "Estimate"])
  se_b <- unname(ivw[2, "Std. Error"])
  indirect <- a_path * b_path
  se_indirect <- sqrt(b_path^2 * se_a^2 + a_path^2 * se_b^2)
  p_indirect <- 2 * pnorm(abs(indirect / se_indirect), lower.tail = FALSE)
  total <- totals[totals$id.outcome == id, ]
  stopifnot(nrow(total) == 1L)

  data.frame(
    key = key, outcome_id = id, outcome = label,
    nsnp = nrow(bx),
    a_smoking_to_bmi = a_path, se_a = se_a,
    smoking_direct_ivw = unname(ivw[1, "Estimate"]),
    se_smoking_direct_ivw = unname(ivw[1, "Std. Error"]),
    p_smoking_direct_ivw = unname(ivw[1, 4]),
    bmi_direct_ivw = b_path, se_bmi_direct_ivw = se_b,
    p_bmi_direct_ivw = unname(ivw[2, 4]),
    bmi_direct_robust = unname(fits$ivw_random_robust@Estimate[2]),
    p_bmi_direct_robust = unname(fits$ivw_random_robust@Pvalue[2]),
    bmi_direct_egger = unname(fits$mv_egger@Estimate[2]),
    p_bmi_direct_egger = unname(fits$mv_egger@Pvalue.Est[2]),
    egger_intercept = unname(fits$mv_egger@Intercept),
    p_egger_intercept = unname(fits$mv_egger@Pvalue.Int),
    bmi_direct_median = unname(fits$mv_median@Estimate[2]),
    p_bmi_direct_median = unname(fits$mv_median@Pvalue[2]),
    total_effect = total$b, se_total = total$se, p_total = total$pval,
    indirect_effect = indirect, se_indirect_zero_cov = se_indirect,
    indirect_lci = indirect - 1.96 * se_indirect,
    indirect_uci = indirect + 1.96 * se_indirect,
    p_indirect = p_indirect,
    descriptive_proportion = indirect / total$b,
    conditional_F_smoking = unname(cond_f[1, 1]),
    conditional_F_bmi = unname(cond_f[1, 2]),
    Q = unname(q_stat$Qstat),
    Q_p = unname(q_stat$Qpval),
    covariance_assumption = "Within-SNP covariance between exposure estimates fixed to zero",
    stringsAsFactors = FALSE
  )
}

results <- do.call(rbind, lapply(seq_len(nrow(outcomes)), function(i) {
  fit_one(outcomes$key[i], outcomes$id[i], outcomes$label[i], i)
}))
results$p_indirect_fdr <- p.adjust(results$p_indirect, method = "BH")
results$p_bmi_direct_ivw_fdr <- p.adjust(results$p_bmi_direct_ivw, method = "BH")
save_csv_rds(results, "mvmr_bmi_outcome_panel_summary")

summary_lines <- c(
  paste0("run_id=", run_id),
  paste0("source_exposure_run=", normalizePath(source_run, winslash = "/", mustWork = TRUE)),
  paste0("output_dir=", normalizePath(outdir, winslash = "/", mustWork = TRUE)),
  paste0("a_path_lifetime_smoking_to_BMI=", signif(a_path, 8), "; SE=", signif(se_a, 8)),
  capture.output(print(results[, c(
    "key", "nsnp", "smoking_direct_ivw", "bmi_direct_ivw", "p_bmi_direct_ivw",
    "indirect_effect", "p_indirect", "p_indirect_fdr", "descriptive_proportion",
    "conditional_F_smoking", "conditional_F_bmi", "Q_p"
  )], row.names = FALSE)),
  "All indirect-effect standard errors use a zero covariance approximation.",
  "Because smoking<->BMI directionality is bidirectional and heterogeneous, mediation results are exploratory."
)
writeLines(summary_lines, file.path(outdir, "run_summary.txt"))
writeLines(capture.output(sessionInfo()), file.path(outdir, "sessionInfo.txt"))
cat(paste(summary_lines, collapse = "\n"), "\n")
