# Offline reconstruction for the BMC submission. Run from the bundle root:
# Rscript code/final_article_analysis.R
options(stringsAsFactors=FALSE)
suppressPackageStartupMessages({library(TwoSampleMR);library(MVMR)})
stopifnot(dir.exists('data_archive'),dir.exists('published_tables'))
dir.create('results',showWarnings=FALSE)
rd <- function(n) read.csv(file.path('data_archive',n),check.names=FALSE)
wr <- function(x,n) write.csv(x,file.path('results',n),row.names=FALSE,na='')
keys <- c('cad','pad_finngen_r5','ais','laa','svs','ces')
labels <- c('Coronary artery disease','Peripheral artery disease','Any ischaemic stroke',
            'Large-artery stroke','Small-vessel stroke','Cardioembolic stroke')
total_old <- rd('all_outcomes_ivw_fdr.csv')
mv_old <- rd('mvmr_bmi_outcome_panel_summary.csv')
het_old <- rd('all_outcomes_heterogeneity.csv')
int_old <- rd('all_outcomes_egger_intercept.csv')
diags <- list(); core <- list(); checks <- list(); loo <- list()
for(i in seq_along(keys)) {
 k <- keys[i];d <- rd(paste0(k,'_harmonised.csv')); d <- d[d$mr_keep %in% TRUE,]
 stopifnot(!anyDuplicated(d$SNP),all(complete.cases(d[,c('beta.exposure','beta.outcome','se.exposure','se.outcome')])))
 iv <- TwoSampleMR::mr_ivw_mre(d$beta.exposure,d$beta.outcome,d$se.exposure,d$se.outcome)
 eg <- TwoSampleMR::mr_egger_regression(d$beta.exposure,d$beta.outcome,d$se.exposure,d$se.outcome,TwoSampleMR::default_parameters())
 # Independent weighted residual calculation verifies the IVW Q statistic.
 w <- 1/d$se.outcome^2
 beta <- sum(w*d$beta.exposure*d$beta.outcome)/sum(w*d$beta.exposure^2)
 q_manual <- sum(w*(d$beta.outcome-beta*d$beta.exposure)^2)
 m <- readRDS(file.path('data_archive',paste0(k,'_mvmr_input.rds')))
 mv <- MVMR::ivw_mvmr(m,gencov=0)
 fs <- MVMR::strength_mvmr(m,gencov=0)
 a <- total_old[total_old$outcome_key==k,];b <- mv_old[mv_old$key==k,]
 h <- het_old[het_old$outcome_key==k & het_old$method=='Inverse variance weighted',]
 e <- het_old[het_old$outcome_key==k & het_old$method=='MR Egger',]
 ip <- int_old[int_old$outcome_key==k,]
 stopifnot(nrow(h)==1L,nrow(e)==1L)
 delta <- max(abs(c(iv$b-a$b,iv$se-a$se,iv$pval-a$pval,
  mv[1,1]-b$smoking_direct_ivw,mv[1,2]-b$se_smoking_direct_ivw,mv[1,4]-b$p_smoking_direct_ivw,
  mv[2,1]-b$bmi_direct_ivw,mv[2,2]-b$se_bmi_direct_ivw,mv[2,4]-b$p_bmi_direct_ivw)))
 diag_delta <- max(abs(c(iv$Q-h$Q,iv$Q_pval-h$Q_pval,eg$Q-e$Q,eg$Q_pval-e$Q_pval,
  eg$b_i-ip$egger_intercept,eg$se_i-ip$se,eg$pval_i-ip$pval,iv$Q-q_manual)))
 checks[[k]] <- data.frame(key=k,core_max_abs_difference=delta,diagnostic_max_abs_difference=diag_delta,
                          pass=delta<1e-10 & diag_delta<1e-9)
 diags[[k]] <- data.frame(outcome_key=k,label=labels[i],nsnp=nrow(d),Q=iv$Q,Q_df=iv$Q_df,Q_pval=iv$Q_pval,
   egger_intercept=eg$b_i,egger_intercept_se=eg$se_i,egger_intercept_p=eg$pval_i,
   old_figure_Egger_Q=eg$Q,old_figure_Egger_Q_df=eg$Q_df,old_figure_Egger_Q_p=eg$Q_pval)
 core[[k]] <- data.frame(key=k,label=labels[i],total_nsnp=nrow(d),mvmr_nsnp=nrow(m),total_b=iv$b,total_se=iv$se,total_p=iv$pval,
   smoking_b=mv[1,1],smoking_se=mv[1,2],smoking_p=mv[1,4],bmi_b=mv[2,1],bmi_se=mv[2,2],bmi_p=mv[2,4],
   F_smoking=as.numeric(fs[1,1]),F_bmi=as.numeric(fs[1,2]))
 loo_b <- vapply(seq_len(nrow(d)),function(j) {x<-d[-j,];ww<-1/x$se.outcome^2;sum(ww*x$beta.exposure*x$beta.outcome)/sum(ww*x$beta.exposure^2)},numeric(1))
 loo[[k]] <- data.frame(key=k,label=labels[i],nsnp=nrow(d),full_b=iv$b,loo_min_b=min(loo_b),loo_max_b=max(loo_b),
   max_abs_change=max(abs(loo_b-iv$b)),most_influential_snp=d$SNP[which.max(abs(loo_b-iv$b))])
}
diagnostics <- do.call(rbind,diags);core <- do.call(rbind,core);checks <- do.call(rbind,checks)
stopifnot(all(checks$pass))
for(p in c('total','smoking','bmi')) {
 core[[paste0(p,'_fdr')]] <- p.adjust(core[[paste0(p,'_p')]],'BH')
 core[[paste0(p,'_or')]] <- exp(core[[paste0(p,'_b')]])
 core[[paste0(p,'_lci')]] <- exp(core[[paste0(p,'_b')]]-1.96*core[[paste0(p,'_se')]])
 core[[paste0(p,'_uci')]] <- exp(core[[paste0(p,'_b')]]+1.96*core[[paste0(p,'_se')]])
}
wr(checks,'verification_checks.csv');wr(core,'core_results_refitted.csv')
wr(diagnostics,'table_s3_univariable_diagnostics.csv')
wr(do.call(rbind,loo),'table_s6_leave_one_out_summary.csv')
# Preserve the frozen stochastic sensitivity estimates; do not silently replace
# published bootstrap outputs with a fresh random realization.
wr(rd('all_outcomes_all_methods.csv'),'table_s2_total_effects_all_estimators.csv')
mv <- mv_old[match(keys,mv_old$key),]
se_bp <- function(b,p) abs(b)/qnorm(p/2,lower.tail=FALSE)
sens <- rbind(
 data.frame(key=keys,method='IVW',b=mv$bmi_direct_ivw,se=mv$se_bmi_direct_ivw,p=mv$p_bmi_direct_ivw),
 data.frame(key=keys,method='Robust IVW',b=mv$bmi_direct_robust,se=se_bp(mv$bmi_direct_robust,mv$p_bmi_direct_robust),p=mv$p_bmi_direct_robust),
 data.frame(key=keys,method='MVMR-Egger',b=mv$bmi_direct_egger,se=se_bp(mv$bmi_direct_egger,mv$p_bmi_direct_egger),p=mv$p_bmi_direct_egger),
 data.frame(key=keys,method='Multivariable median',b=mv$bmi_direct_median,se=se_bp(mv$bmi_direct_median,mv$p_bmi_direct_median),p=mv$p_bmi_direct_median))
sens$label<-labels[match(sens$key,keys)];sens$or<-exp(sens$b);sens$lci<-exp(sens$b-1.96*sens$se);sens$uci<-exp(sens$b+1.96*sens$se)
wr(sens,'table_s4_mvmr_bmi_sensitivity.csv')
x<-rd('x_to_m_mr.csv');rev<-rd('reverse_bmi_to_lifetime_mr.csv')
direction<-rbind(data.frame(direction='Lifetime smoking to BMI',method=x$method,nsnp=x$nsnp,b=x$b,se=x$se,p=x$pval),
 data.frame(direction='BMI to lifetime smoking',method=rev$method,nsnp=rev$nsnp,b=rev$b,se=rev$se,p=rev$pval))
direction$lci<-direction$b-1.96*direction$se;direction$uci<-direction$b+1.96*direction$se
wr(direction,'table_s5_bidirectional_smoking_bmi.csv')
wr(core,'table_s7_primary_direct_effects.csv')
a<-x[x$method=='Inverse variance weighted (multiplicative random effects)',]
ind<-data.frame(key=keys,label=labels,indirect_log_or=a$b*core$bmi_b,
 se=sqrt(core$bmi_b^2*a$se^2+a$b^2*core$bmi_se^2))
ind$lci<-ind$indirect_log_or-1.96*ind$se;ind$uci<-ind$indirect_log_or+1.96*ind$se
ind$p<-2*pnorm(abs(ind$indirect_log_or/ind$se),lower.tail=FALSE);ind$fdr<-p.adjust(ind$p,'BH')
ind$descriptive_proportion<-ifelse(core$total_p<0.05 & sign(ind$indirect_log_or)==sign(core$total_b),ind$indirect_log_or/core$total_b,NA)
stopifnot(max(abs(ind$indirect_log_or-mv$indirect_effect))<1e-10,max(abs(ind$p-mv$p_indirect))<1e-10)
wr(ind,'table_s8_exploratory_indirect_effects.csv')
# Dataset metadata is transcribed verbatim from the submitted Table S1, including
# the already-corrected MEGASTROKE subtype control counts; no source GWAS is changed.
file.copy('published_tables/Table_S1.csv','results/table_s1_data_sources.csv',overwrite=TRUE)
source('code/plot_FigS2.R')
writeLines(capture.output(sessionInfo()),'results/sessionInfo_current.txt')
writeLines(c('PASS: six outcome IVW and mutually adjusted smoking/BMI models match frozen estimates.',
 'PASS: IVW Q, MR-Egger Q and intercept diagnostics reproduced from harmonized SNP data.',
 'PASS: IVW Q independently verified by weighted squared residuals.',
 'PASS: exploratory product estimates reproduced with zero covariance delta variance.',
 'The original FigS2 heterogeneity panel used the MR-Egger Q rows; the corrected panel explicitly uses IVW Q.',
 'Frozen stochastic median/mode and sensitivity outputs are supplied with original code and saved fits; they are not represented as newly rerun.'),'results/verification_summary.txt')
print(checks);print(diagnostics[,c('outcome_key','Q','Q_df','Q_pval','old_figure_Egger_Q')])
