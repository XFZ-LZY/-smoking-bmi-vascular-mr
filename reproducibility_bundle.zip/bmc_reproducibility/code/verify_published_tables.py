"""Compare all displayed numeric cells in Tables S2-S8 to frozen/refitted outputs.
Uses only the Python standard library; rounding tolerance follows each printed cell.
Run: python code/verify_published_tables.py
"""
from pathlib import Path
import csv, re, json, math
root=Path.cwd()
def rows(p): return list(csv.DictReader((root/p).open(encoding='utf-8-sig',newline='')))
def table(i):return list(csv.reader((root/f'published_tables/Table_S{i}.csv').open(encoding='utf-8-sig',newline='')))[1:]
def n(x):return float(x)
checks=[]
def compare(tab,row,col,printed,expected):
    s=printed.translate(str.maketrans('⁰¹²³⁴⁵⁶⁷⁸⁹⁻','0123456789-')).replace('−','-').replace('–',' ')
    s=re.sub(r'\s*[×x]\s*10\s*([+-]?\d+)',r'e\1',s)
    tokens=re.findall(r'[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?',s)
    assert len(tokens)==len(expected),(tab,row,col,printed,expected)
    for token,value in zip(tokens,expected):
        mantissa,_,exponent=token.lower().partition('e')
        decimals=len(mantissa.split('.')[1]) if '.' in mantissa else 0
        tol=0.50001*10**(int(exponent or 0)-decimals)
        actual=float(token);passed=abs(actual-float(value))<=tol+1e-12
        checks.append(dict(table=tab,row=row,column=col,displayed=token,source_value=value,tolerance=tol,pass_check=passed))
def cells(t,rr,mapping):
    published=table(t);assert len(published)==len(rr),(t,len(published),len(rr))
    for i,(p,r) in enumerate(zip(published,rr),1):
        for c,fn in mapping.items(): compare(t,i,c,p[c],fn(r))
cells(2,rows('results/table_s2_total_effects_all_estimators.csv'),{
 2:lambda r:[n(r['nsnp'])],3:lambda r:[n(r['or'])],4:lambda r:[n(r['or_lci95']),n(r['or_uci95'])],5:lambda r:[n(r['pval'])]})
cells(3,rows('results/table_s3_univariable_diagnostics.csv'),{
 1:lambda r:[n(r['Q'])],2:lambda r:[n(r['Q_df'])],3:lambda r:[n(r['Q_pval'])],4:lambda r:[n(r['egger_intercept'])],5:lambda r:[n(r['egger_intercept_se'])],6:lambda r:[n(r['egger_intercept_p'])]})
cells(4,rows('results/table_s4_mvmr_bmi_sensitivity.csv'),{
 2:lambda r:[n(r['or'])],3:lambda r:[n(r['lci']),n(r['uci'])],4:lambda r:[n(r['p'])]})
cells(5,rows('results/table_s5_bidirectional_smoking_bmi.csv'),{
 2:lambda r:[n(r['nsnp'])],3:lambda r:[n(r['b'])],4:lambda r:[n(r['se'])],5:lambda r:[n(r['lci']),n(r['uci'])],6:lambda r:[n(r['p'])]})
loo=rows('results/table_s6_leave_one_out_summary.csv')
cells(6,loo,{1:lambda r:[n(r['nsnp'])],2:lambda r:[n(r['full_b'])],3:lambda r:[n(r['loo_min_b']),n(r['loo_max_b'])],4:lambda r:[n(r['max_abs_change'])]})
assert all(p[5]==r['most_influential_snp'] for p,r in zip(table(6),loo))
core=rows('results/core_results_refitted.csv');mv=rows('data_archive/mvmr_bmi_outcome_panel_summary.csv')
bykey={r['key']:r for r in mv}
for r in core:r['residual_Q_p']=bykey[r['key']]['Q_p']
cells(7,core,{
 1:lambda r:[n(r['mvmr_nsnp'])],2:lambda r:[n(r['smoking_or']),n(r['smoking_lci']),n(r['smoking_uci'])],
 3:lambda r:[n(r['smoking_fdr'])],4:lambda r:[n(r['bmi_or']),n(r['bmi_lci']),n(r['bmi_uci'])],
 5:lambda r:[n(r['bmi_fdr'])],6:lambda r:[n(r['F_smoking']),n(r['F_bmi'])],7:lambda r:[n(r['residual_Q_p'])]})
ind=rows('results/table_s8_exploratory_indirect_effects.csv')
cells(8,ind,{1:lambda r:[n(r['indirect_log_or']),n(r['lci']),n(r['uci'])],2:lambda r:[n(r['p'])],3:lambda r:[n(r['fdr'])]})
for i,(p,r) in enumerate(zip(table(8),ind),1):
 if p[4]=='Not interpreted': assert r['descriptive_proportion']==''
 else:compare(8,i,4,p[4],[n(r['descriptive_proportion'])*100])
with (root/'results/published_table_numeric_checks.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=checks[0].keys());w.writeheader();w.writerows(checks)
bad=[x for x in checks if not x['pass_check']]
report={'numeric_values_checked':len(checks),'passed':len(checks)-len(bad),'failed':len(bad),'failures':bad}
(root/'results/published_table_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
assert not bad,'Published table mismatch; inspect report before packaging'
