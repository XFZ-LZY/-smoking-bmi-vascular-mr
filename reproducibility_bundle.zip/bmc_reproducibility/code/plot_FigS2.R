suppressPackageStartupMessages({library(ggplot2);library(patchwork)})
d<-read.csv('results/table_s3_univariable_diagnostics.csv',check.names=FALSE)
stopifnot(nrow(d)==6L,all(d$Q_df==d$nsnp-1))
dir.create('figures',showWarnings=FALSE)
fP<-function(x) ifelse(x<0.001,formatC(x,format='e',digits=2),sprintf('%.3f',x))
d$y<-rev(seq_len(nrow(d)))
d$qlabel<-paste0(sprintf('Q = %.3f',d$Q),'; P = ',fP(d$Q_pval))
d$ilabel<-paste0(sprintf('Intercept = %.5f',d$egger_intercept),'; P = ',fP(d$egger_intercept_p))
base<-theme_classic(base_size=11,base_family='sans')+
 theme(axis.title.y=element_blank(),axis.line.y=element_blank(),axis.ticks.y=element_blank(),
 axis.text.y=element_text(colour='black',size=11),plot.title=element_text(size=12,face='bold'),
 plot.margin=margin(10,12,10,8),panel.grid.major.y=element_blank())
p1<-ggplot(d,aes(y=y))+geom_segment(aes(x=0,xend=Q,yend=y),colour='#BFC2C5',linewidth=.7)+
 geom_point(aes(x=Q,fill=Q_pval<.05),shape=21,size=3.2,colour='#555555')+
 geom_text(aes(x=5,label=qlabel),nudge_y=.30,hjust=0,size=3.7)+
 scale_fill_manual(values=c('FALSE'='white','TRUE'='#B34432'),guide='none')+
 scale_y_continuous(breaks=d$y,labels=d$label,limits=c(.55,6.6))+
 scale_x_continuous(limits=c(0,210),breaks=seq(0,200,50),expand=expansion(mult=c(.02,.03)))+
 labs(x='Cochran Q (IVW)',title='a  IVW heterogeneity')+base
p2<-ggplot(d,aes(y=y))+geom_vline(xintercept=0,linetype='dashed',colour='#BFC2C5')+
 geom_point(aes(x=egger_intercept,fill=egger_intercept_p<.05),shape=21,size=3.2,colour='#555555')+
 geom_text(aes(x=-.020,label=ilabel),nudge_y=.30,hjust=0,size=3.7)+
 scale_fill_manual(values=c('FALSE'='white','TRUE'='#B34432'),guide='none')+
 scale_y_continuous(breaks=d$y,labels=NULL,limits=c(.55,6.6))+
 scale_x_continuous(limits=c(-.022,.023),breaks=c(-.02,-.01,0,.01,.02))+
 labs(x='MR-Egger intercept',title='b  Directional pleiotropy')+base
p<-p1+p2+plot_layout(widths=c(1,1.05))
ggsave('figures/FigS2.png',p,width=10,height=10*2040/4440,units='in',dpi=444,bg='white')
ggsave('figures/FigS2.pdf',p,width=10,height=10*2040/4440,units='in',bg='white')
write.csv(d,'results/FigS2_plot_data.csv',row.names=FALSE)
